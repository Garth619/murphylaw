# WordPress MySQL database migration
#
# Generated: Tuesday 13. February 2018 00:18 UTC
# Hostname: localhost
# Database: `murphylaw`
# URL: //murphylaw.com
# Path: /Applications/MAMP/htdocs/murphylaw
# Tables: wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_rg_form, wp_rg_form_meta, wp_rg_form_view, wp_rg_incomplete_submissions, wp_rg_lead, wp_rg_lead_detail, wp_rg_lead_detail_long, wp_rg_lead_meta, wp_rg_lead_notes, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, nav_menu_item, page, post
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2018-01-29 21:34:28', '2018-01-29 21:34:28', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, 'post-trashed', '', '', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=569 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://murphylaw.com', 'yes'),
(2, 'home', 'http://murphylaw.com', 'yes'),
(3, 'blogname', 'Murphy Law Firm, LLC', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'garrett@1pointinteractive.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '3', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:91:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=6&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:3:{i:0;s:29:"gravityforms/gravityforms.php";i:1;s:38:"post-duplicator/m4c-postduplicator.php";i:2;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'murphylaw', 'yes'),
(41, 'stylesheet', 'murphylaw', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:3;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '71', 'yes'),
(84, 'page_on_front', '6', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_archives', 'a:2:{i:3;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'sidebars_widgets', 'a:5:{s:19:"wp_inactive_widgets";a:0:{}s:7:"sidebar";a:1:{i:0;s:14:"recent-posts-2";}s:16:"category_sidebar";a:1:{i:0;s:12:"categories-3";}s:15:"archive_sidebar";a:1:{i:0;s:10:"archives-3";}s:13:"array_version";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'cron', 'a:5:{i:1518514469;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1518557686;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1518558618;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1518558764;a:1:{s:17:"gravityforms_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(127, 'can_compress_scripts', '0', 'no'),
(133, 'theme_mods_twentyseventeen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1517261696;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(134, 'current_theme', '', 'yes'),
(135, 'theme_mods_murphylaw', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:2:{s:9:"main_menu";i:2;s:7:"pa_menu";i:3;}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(136, 'theme_switched', '', 'yes'),
(139, 'WPLANG', '', 'yes'),
(140, 'new_admin_email', 'garrett@1pointinteractive.com', 'yes'),
(196, 'recently_activated', 'a:0:{}', 'yes'),
(200, 'widget_gform_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(201, 'rg_form_version', '2.2.5', 'yes'),
(204, 'rg_gforms_key', '621e21584ab7936611e0d28422299c97', 'yes'),
(205, 'rg_gforms_disable_css', '1', 'yes'),
(206, 'rg_gforms_enable_html5', '0', 'yes'),
(207, 'gform_enable_noconflict', '0', 'yes'),
(208, 'rg_gforms_enable_akismet', '', 'yes'),
(209, 'rg_gforms_captcha_public_key', '', 'yes'),
(210, 'rg_gforms_captcha_private_key', '', 'yes'),
(211, 'rg_gforms_currency', 'USD', 'yes'),
(212, 'rg_gforms_message', '<!--GFM-->', 'yes'),
(216, 'gravityformsaddon_gravityformswebapi_version', '1.0', 'yes'),
(217, 'gf_is_upgrading', '0', 'yes'),
(218, 'gf_previous_db_version', '0', 'yes'),
(219, 'gf_db_version', '2.2.5', 'yes'),
(267, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(449, 'mtphr_post_duplicator_settings', '', 'yes'),
(456, 'category_children', 'a:0:{}', 'yes'),
(491, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1518481083;}', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=346 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 2, '_wp_trash_meta_status', 'publish'),
(3, 2, '_wp_trash_meta_time', '1517262610'),
(4, 2, '_wp_desired_post_slug', 'sample-page'),
(5, 1, '_wp_trash_meta_status', 'publish'),
(6, 1, '_wp_trash_meta_time', '1517262613'),
(7, 1, '_wp_desired_post_slug', 'hello-world'),
(8, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:"1";}'),
(9, 6, '_edit_last', '1'),
(10, 6, '_edit_lock', '1517262487:1'),
(11, 6, '_wp_page_template', 'page-home.php'),
(12, 8, '_edit_last', '1'),
(13, 8, '_edit_lock', '1518373645:1'),
(14, 8, '_wp_page_template', 'page-about.php'),
(15, 10, '_edit_last', '1'),
(16, 10, '_wp_page_template', 'page-bio.php'),
(17, 10, '_edit_lock', '1518373493:1'),
(18, 12, '_edit_last', '1'),
(19, 12, '_wp_page_template', 'default'),
(20, 12, '_edit_lock', '1518455909:1'),
(21, 14, '_edit_last', '1'),
(22, 14, '_wp_page_template', 'page-caseresults.php'),
(23, 14, '_edit_lock', '1518116950:1'),
(24, 16, '_edit_last', '1'),
(25, 16, '_wp_page_template', 'page-testimonials.php'),
(26, 16, '_edit_lock', '1518116798:1'),
(27, 18, '_edit_last', '1'),
(28, 18, '_edit_lock', '1518310865:1'),
(29, 18, '_wp_page_template', 'page-contact.php'),
(30, 20, '_menu_item_type', 'post_type'),
(31, 20, '_menu_item_menu_item_parent', '0'),
(32, 20, '_menu_item_object_id', '6'),
(33, 20, '_menu_item_object', 'page'),
(34, 20, '_menu_item_target', ''),
(35, 20, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(36, 20, '_menu_item_xfn', ''),
(37, 20, '_menu_item_url', ''),
(39, 21, '_menu_item_type', 'post_type'),
(40, 21, '_menu_item_menu_item_parent', '0'),
(41, 21, '_menu_item_object_id', '8'),
(42, 21, '_menu_item_object', 'page'),
(43, 21, '_menu_item_target', ''),
(44, 21, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(45, 21, '_menu_item_xfn', ''),
(46, 21, '_menu_item_url', ''),
(48, 22, '_menu_item_type', 'post_type'),
(49, 22, '_menu_item_menu_item_parent', '28'),
(50, 22, '_menu_item_object_id', '10'),
(51, 22, '_menu_item_object', 'page'),
(52, 22, '_menu_item_target', ''),
(53, 22, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(54, 22, '_menu_item_xfn', ''),
(55, 22, '_menu_item_url', ''),
(57, 23, '_menu_item_type', 'post_type'),
(58, 23, '_menu_item_menu_item_parent', '0'),
(59, 23, '_menu_item_object_id', '14'),
(60, 23, '_menu_item_object', 'page'),
(61, 23, '_menu_item_target', ''),
(62, 23, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(63, 23, '_menu_item_xfn', ''),
(64, 23, '_menu_item_url', ''),
(66, 24, '_menu_item_type', 'post_type'),
(67, 24, '_menu_item_menu_item_parent', '0'),
(68, 24, '_menu_item_object_id', '18'),
(69, 24, '_menu_item_object', 'page'),
(70, 24, '_menu_item_target', ''),
(71, 24, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(72, 24, '_menu_item_xfn', ''),
(73, 24, '_menu_item_url', ''),
(75, 25, '_menu_item_type', 'post_type'),
(76, 25, '_menu_item_menu_item_parent', '0'),
(77, 25, '_menu_item_object_id', '6'),
(78, 25, '_menu_item_object', 'page'),
(79, 25, '_menu_item_target', ''),
(80, 25, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(81, 25, '_menu_item_xfn', ''),
(82, 25, '_menu_item_url', ''),
(83, 25, '_menu_item_orphaned', '1517954219'),
(84, 26, '_menu_item_type', 'post_type'),
(85, 26, '_menu_item_menu_item_parent', '31'),
(86, 26, '_menu_item_object_id', '12'),
(87, 26, '_menu_item_object', 'page'),
(88, 26, '_menu_item_target', ''),
(89, 26, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(90, 26, '_menu_item_xfn', ''),
(91, 26, '_menu_item_url', ''),
(93, 27, '_menu_item_type', 'post_type'),
(94, 27, '_menu_item_menu_item_parent', '0'),
(95, 27, '_menu_item_object_id', '16'),
(96, 27, '_menu_item_object', 'page'),
(97, 27, '_menu_item_target', ''),
(98, 27, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(99, 27, '_menu_item_xfn', ''),
(100, 27, '_menu_item_url', ''),
(102, 28, '_menu_item_type', 'custom'),
(103, 28, '_menu_item_menu_item_parent', '0'),
(104, 28, '_menu_item_object_id', '28'),
(105, 28, '_menu_item_object', 'custom'),
(106, 28, '_menu_item_target', ''),
(107, 28, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(108, 28, '_menu_item_xfn', ''),
(109, 28, '_menu_item_url', ''),
(111, 29, '_menu_item_type', 'post_type'),
(112, 29, '_menu_item_menu_item_parent', '28'),
(113, 29, '_menu_item_object_id', '10'),
(114, 29, '_menu_item_object', 'page'),
(115, 29, '_menu_item_target', ''),
(116, 29, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(117, 29, '_menu_item_xfn', ''),
(118, 29, '_menu_item_url', ''),
(120, 30, '_menu_item_type', 'post_type'),
(121, 30, '_menu_item_menu_item_parent', '28'),
(122, 30, '_menu_item_object_id', '10'),
(123, 30, '_menu_item_object', 'page'),
(124, 30, '_menu_item_target', ''),
(125, 30, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(126, 30, '_menu_item_xfn', ''),
(127, 30, '_menu_item_url', ''),
(129, 31, '_menu_item_type', 'custom'),
(130, 31, '_menu_item_menu_item_parent', '0'),
(131, 31, '_menu_item_object_id', '31'),
(132, 31, '_menu_item_object', 'custom'),
(133, 31, '_menu_item_target', ''),
(134, 31, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(135, 31, '_menu_item_xfn', ''),
(136, 31, '_menu_item_url', ''),
(138, 32, '_menu_item_type', 'post_type'),
(139, 32, '_menu_item_menu_item_parent', '31'),
(140, 32, '_menu_item_object_id', '12'),
(141, 32, '_menu_item_object', 'page'),
(142, 32, '_menu_item_target', ''),
(143, 32, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(144, 32, '_menu_item_xfn', ''),
(145, 32, '_menu_item_url', ''),
(147, 33, '_menu_item_type', 'post_type'),
(148, 33, '_menu_item_menu_item_parent', '31'),
(149, 33, '_menu_item_object_id', '12'),
(150, 33, '_menu_item_object', 'page'),
(151, 33, '_menu_item_target', ''),
(152, 33, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(153, 33, '_menu_item_xfn', ''),
(154, 33, '_menu_item_url', ''),
(155, 35, '_edit_last', '1'),
(156, 35, '_edit_lock', '1518455853:1'),
(157, 35, '_wp_page_template', 'default'),
(158, 37, '_edit_last', '1'),
(159, 37, '_wp_page_template', 'default'),
(160, 37, '_edit_lock', '1518454128:1'),
(161, 39, '_edit_last', '1'),
(162, 39, '_wp_page_template', 'default'),
(163, 39, '_edit_lock', '1518454129:1'),
(164, 41, '_edit_last', '1'),
(165, 41, '_wp_page_template', 'default'),
(166, 41, '_edit_lock', '1518455806:1'),
(167, 43, '_edit_last', '1'),
(168, 43, '_wp_page_template', 'default'),
(169, 43, '_edit_lock', '1518454128:1'),
(170, 45, '_edit_last', '1'),
(171, 45, '_wp_page_template', 'default'),
(172, 45, '_edit_lock', '1518454129:1'),
(173, 47, '_menu_item_type', 'custom'),
(174, 47, '_menu_item_menu_item_parent', '0'),
(175, 47, '_menu_item_object_id', '47'),
(176, 47, '_menu_item_object', 'custom'),
(177, 47, '_menu_item_target', ''),
(178, 47, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(179, 47, '_menu_item_xfn', ''),
(180, 47, '_menu_item_url', '#'),
(181, 47, '_menu_item_orphaned', '1518041576'),
(182, 48, '_menu_item_type', 'post_type'),
(183, 48, '_menu_item_menu_item_parent', '57'),
(184, 48, '_menu_item_object_id', '45'),
(185, 48, '_menu_item_object', 'page'),
(186, 48, '_menu_item_target', ''),
(187, 48, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(188, 48, '_menu_item_xfn', ''),
(189, 48, '_menu_item_url', ''),
(191, 49, '_menu_item_type', 'post_type'),
(192, 49, '_menu_item_menu_item_parent', '57'),
(193, 49, '_menu_item_object_id', '43'),
(194, 49, '_menu_item_object', 'page'),
(195, 49, '_menu_item_target', ''),
(196, 49, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(197, 49, '_menu_item_xfn', ''),
(198, 49, '_menu_item_url', ''),
(200, 50, '_menu_item_type', 'post_type'),
(201, 50, '_menu_item_menu_item_parent', '56'),
(202, 50, '_menu_item_object_id', '41'),
(203, 50, '_menu_item_object', 'page'),
(204, 50, '_menu_item_target', ''),
(205, 50, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(206, 50, '_menu_item_xfn', ''),
(207, 50, '_menu_item_url', ''),
(209, 51, '_menu_item_type', 'post_type'),
(210, 51, '_menu_item_menu_item_parent', '56'),
(211, 51, '_menu_item_object_id', '39'),
(212, 51, '_menu_item_object', 'page'),
(213, 51, '_menu_item_target', ''),
(214, 51, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(215, 51, '_menu_item_xfn', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(216, 51, '_menu_item_url', ''),
(218, 52, '_menu_item_type', 'post_type'),
(219, 52, '_menu_item_menu_item_parent', '55'),
(220, 52, '_menu_item_object_id', '37'),
(221, 52, '_menu_item_object', 'page'),
(222, 52, '_menu_item_target', ''),
(223, 52, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(224, 52, '_menu_item_xfn', ''),
(225, 52, '_menu_item_url', ''),
(227, 53, '_menu_item_type', 'post_type'),
(228, 53, '_menu_item_menu_item_parent', '55'),
(229, 53, '_menu_item_object_id', '35'),
(230, 53, '_menu_item_object', 'page'),
(231, 53, '_menu_item_target', ''),
(232, 53, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(233, 53, '_menu_item_xfn', ''),
(234, 53, '_menu_item_url', ''),
(236, 54, '_menu_item_type', 'post_type'),
(237, 54, '_menu_item_menu_item_parent', '55'),
(238, 54, '_menu_item_object_id', '12'),
(239, 54, '_menu_item_object', 'page'),
(240, 54, '_menu_item_target', ''),
(241, 54, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(242, 54, '_menu_item_xfn', ''),
(243, 54, '_menu_item_url', ''),
(245, 55, '_menu_item_type', 'custom'),
(246, 55, '_menu_item_menu_item_parent', '0'),
(247, 55, '_menu_item_object_id', '55'),
(248, 55, '_menu_item_object', 'custom'),
(249, 55, '_menu_item_target', ''),
(250, 55, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(251, 55, '_menu_item_xfn', ''),
(252, 55, '_menu_item_url', ''),
(254, 56, '_menu_item_type', 'custom'),
(255, 56, '_menu_item_menu_item_parent', '0'),
(256, 56, '_menu_item_object_id', '56'),
(257, 56, '_menu_item_object', 'custom'),
(258, 56, '_menu_item_target', ''),
(259, 56, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(260, 56, '_menu_item_xfn', ''),
(261, 56, '_menu_item_url', ''),
(263, 57, '_menu_item_type', 'custom'),
(264, 57, '_menu_item_menu_item_parent', '0'),
(265, 57, '_menu_item_object_id', '57'),
(266, 57, '_menu_item_object', 'custom'),
(267, 57, '_menu_item_target', ''),
(268, 57, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(269, 57, '_menu_item_xfn', ''),
(270, 57, '_menu_item_url', ''),
(271, 59, '_menu_item_type', 'post_type'),
(272, 59, '_menu_item_menu_item_parent', '55'),
(273, 59, '_menu_item_object_id', '12'),
(274, 59, '_menu_item_object', 'page'),
(275, 59, '_menu_item_target', ''),
(276, 59, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(277, 59, '_menu_item_xfn', ''),
(278, 59, '_menu_item_url', ''),
(280, 60, '_edit_last', '1'),
(281, 60, '_edit_lock', '1518132067:1'),
(282, 60, '_wp_page_template', 'page-practiceareas.php'),
(283, 62, '_menu_item_type', 'post_type'),
(284, 62, '_menu_item_menu_item_parent', '31'),
(285, 62, '_menu_item_object_id', '60'),
(286, 62, '_menu_item_object', 'page'),
(287, 62, '_menu_item_target', ''),
(288, 62, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(289, 62, '_menu_item_xfn', ''),
(290, 62, '_menu_item_url', ''),
(291, 63, '_edit_last', '1'),
(292, 63, '_edit_lock', '1518197698:1'),
(293, 63, '_wp_page_template', 'page-videocenter.php'),
(294, 65, '_menu_item_type', 'post_type'),
(295, 65, '_menu_item_menu_item_parent', '0'),
(296, 65, '_menu_item_object_id', '63'),
(297, 65, '_menu_item_object', 'page'),
(298, 65, '_menu_item_target', ''),
(299, 65, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(300, 65, '_menu_item_xfn', ''),
(301, 65, '_menu_item_url', ''),
(303, 66, '_edit_last', '1'),
(304, 66, '_edit_lock', '1518202597:1'),
(305, 66, '_wp_page_template', 'page-meetteam.php'),
(306, 68, '_menu_item_type', 'post_type'),
(307, 68, '_menu_item_menu_item_parent', '28'),
(308, 68, '_menu_item_object_id', '66'),
(309, 68, '_menu_item_object', 'page'),
(310, 68, '_menu_item_target', ''),
(311, 68, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(312, 68, '_menu_item_xfn', ''),
(313, 68, '_menu_item_url', ''),
(314, 71, '_edit_last', '1'),
(315, 71, '_edit_lock', '1518392958:1'),
(316, 71, '_wp_page_template', 'page-blog.php'),
(317, 73, '_menu_item_type', 'post_type'),
(318, 73, '_menu_item_menu_item_parent', '0'),
(319, 73, '_menu_item_object_id', '71'),
(320, 73, '_menu_item_object', 'page'),
(321, 73, '_menu_item_target', ''),
(322, 73, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(323, 73, '_menu_item_xfn', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(324, 73, '_menu_item_url', ''),
(326, 74, '_edit_last', '1'),
(327, 74, '_edit_lock', '1518393187:1'),
(330, 76, '_edit_last', '1'),
(331, 76, '_edit_lock', '1518393187:1'),
(333, 77, '_edit_last', '1'),
(334, 77, '_edit_lock', '1518393187:1'),
(336, 78, '_edit_last', '1'),
(337, 78, '_edit_lock', '1518393187:1'),
(339, 79, '_edit_last', '1'),
(340, 79, '_edit_lock', '1518400379:1'),
(343, 82, '_edit_last', '1'),
(344, 82, '_edit_lock', '1518453876:1'),
(345, 82, '_wp_page_template', 'default') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2018-01-29 21:34:28', '2018-01-29 21:34:28', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world__trashed', '', '', '2018-01-29 21:50:13', '2018-01-29 21:50:13', '', 0, 'http://murphylaw.com/?p=1', 0, 'post', '', 1),
(2, 1, '2018-01-29 21:34:28', '2018-01-29 21:34:28', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://murphylaw.com/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'trash', 'closed', 'open', '', 'sample-page__trashed', '', '', '2018-01-29 21:50:10', '2018-01-29 21:50:10', '', 0, 'http://murphylaw.com/?page_id=2', 0, 'page', '', 0),
(4, 1, '2018-01-29 21:50:10', '2018-01-29 21:50:10', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://murphylaw.com/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2018-01-29 21:50:10', '2018-01-29 21:50:10', '', 2, 'http://murphylaw.com/2018/01/29/2-revision-v1/', 0, 'revision', '', 0),
(5, 1, '2018-01-29 21:50:13', '2018-01-29 21:50:13', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2018-01-29 21:50:13', '2018-01-29 21:50:13', '', 1, 'http://murphylaw.com/2018/01/29/1-revision-v1/', 0, 'revision', '', 0),
(6, 1, '2018-01-29 21:50:25', '2018-01-29 21:50:25', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2018-01-29 21:50:25', '2018-01-29 21:50:25', '', 0, 'http://murphylaw.com/?page_id=6', 0, 'page', '', 0),
(7, 1, '2018-01-29 21:50:25', '2018-01-29 21:50:25', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2018-01-29 21:50:25', '2018-01-29 21:50:25', '', 6, 'http://murphylaw.com/2018/01/29/6-revision-v1/', 0, 'revision', '', 0),
(8, 1, '2018-02-06 21:55:47', '2018-02-06 21:55:47', '', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2018-02-11 18:27:25', '2018-02-11 18:27:25', '', 0, 'http://murphylaw.com/?page_id=8', 0, 'page', '', 0),
(9, 1, '2018-02-06 21:55:47', '2018-02-06 21:55:47', '', 'About', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2018-02-06 21:55:47', '2018-02-06 21:55:47', '', 8, 'http://murphylaw.com/2018/02/06/8-revision-v1/', 0, 'revision', '', 0),
(10, 1, '2018-02-06 21:56:04', '2018-02-06 21:56:04', '', 'Peyton Murphy', '', 'publish', 'closed', 'closed', '', 'peyton-murphy', '', '', '2018-02-11 02:03:21', '2018-02-11 02:03:21', '', 0, 'http://murphylaw.com/?page_id=10', 0, 'page', '', 0),
(11, 1, '2018-02-06 21:56:04', '2018-02-06 21:56:04', '', 'Attorney Name', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2018-02-06 21:56:04', '2018-02-06 21:56:04', '', 10, 'http://murphylaw.com/2018/02/06/10-revision-v1/', 0, 'revision', '', 0),
(12, 1, '2018-02-06 21:56:18', '2018-02-06 21:56:18', '<h2>Heading Style 2 - Lorem ipsum dolor sit amet, consectetur adipiscing</h2>\r\n		\r\n		<p>Quisque non egestas justo, ac pellentesque dolor. In et diam sagittis, semper lorem id, blandit velit. Integer mattis metus vel nisi commodo porttitor. Aenean commodo commodo facilisis. Nam arcu erat, lacinia sed lacinia quis, pretium eget enim. <a href="">Embedded Link</a>  ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed maximus quam vestibulum imperdiet interdum. Cras rhoncus arcu ornare sapien sollicitudin pulvinar. Vivamus placerat purus sit amet sapien malesuada feugiat. Ut accumsan finibus nunc.</p>\r\n\r\n		<blockquote>Pull Quote : Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc id quam at nisi venenatis tempus eget vel orci neque id euismod.</blockquote>\r\n\r\n		<h3>Heading style 3</h3>\r\n\r\n		<p>Mauris vel tristique mi. Aenean libero tortor, condimentum eget efficitur sed, pulvinar dictum elit. Duis viverra lacus nec leo lacinia fringilla. Ut et est nulla. Vestibulum iaculis quam sapien, finibus luctus arcu convallis vitae. </p>\r\n		\r\n		<ol>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	       Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		</ol>\r\n\r\n		<h4>Heading Style 4</h4>\r\n\r\n		<p>In ullamcorper tempor velit in mattis. Nullam cursus sollicitudin sem, a cursus magna porta ac. In a justo tristique, auctor leo nec, gravida orci. Quisque massa nisi, imperdiet a imperdiet non, rutrum in justo. Cras tempus sollicitudin ipsum, et mattis augue porttitor et.</p>\r\n		\r\n		<ul>\r\n			\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	       	    eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		\r\n		</ul>', 'Car Accident Lawyers', '', 'publish', 'closed', 'closed', '', 'practice-area-examples', '', '', '2018-02-12 17:20:25', '2018-02-12 17:20:25', '', 0, 'http://murphylaw.com/?page_id=12', 0, 'page', '', 0),
(13, 1, '2018-02-06 21:56:18', '2018-02-06 21:56:18', '', 'Practice Area Examples', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2018-02-06 21:56:18', '2018-02-06 21:56:18', '', 12, 'http://murphylaw.com/2018/02/06/12-revision-v1/', 0, 'revision', '', 0),
(14, 1, '2018-02-06 21:56:28', '2018-02-06 21:56:28', '', 'Case Results', '', 'publish', 'closed', 'closed', '', 'case-results', '', '', '2018-02-08 19:09:10', '2018-02-08 19:09:10', '', 0, 'http://murphylaw.com/?page_id=14', 0, 'page', '', 0),
(15, 1, '2018-02-06 21:56:28', '2018-02-06 21:56:28', '', 'Case Results', '', 'inherit', 'closed', 'closed', '', '14-revision-v1', '', '', '2018-02-06 21:56:28', '2018-02-06 21:56:28', '', 14, 'http://murphylaw.com/2018/02/06/14-revision-v1/', 0, 'revision', '', 0),
(16, 1, '2018-02-06 21:56:38', '2018-02-06 21:56:38', '', 'Client Testimonials', '', 'publish', 'closed', 'closed', '', 'testimonials', '', '', '2018-02-08 17:50:24', '2018-02-08 17:50:24', '', 0, 'http://murphylaw.com/?page_id=16', 0, 'page', '', 0),
(17, 1, '2018-02-06 21:56:38', '2018-02-06 21:56:38', '', 'Testimonials', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2018-02-06 21:56:38', '2018-02-06 21:56:38', '', 16, 'http://murphylaw.com/2018/02/06/16-revision-v1/', 0, 'revision', '', 0),
(18, 1, '2018-02-06 21:56:45', '2018-02-06 21:56:45', '', 'Contact Us', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2018-02-11 01:01:05', '2018-02-11 01:01:05', '', 0, 'http://murphylaw.com/?page_id=18', 0, 'page', '', 0),
(19, 1, '2018-02-06 21:56:45', '2018-02-06 21:56:45', '', 'Contact', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2018-02-06 21:56:45', '2018-02-06 21:56:45', '', 18, 'http://murphylaw.com/2018/02/06/18-revision-v1/', 0, 'revision', '', 0),
(20, 1, '2018-02-06 21:59:01', '2018-02-06 21:59:01', ' ', '', '', 'publish', 'closed', 'closed', '', '20', '', '', '2018-02-12 16:49:53', '2018-02-12 16:49:53', '', 0, 'http://murphylaw.com/?p=20', 1, 'nav_menu_item', '', 0),
(21, 1, '2018-02-06 21:59:01', '2018-02-06 21:59:01', ' ', '', '', 'publish', 'closed', 'closed', '', '21', '', '', '2018-02-12 16:49:53', '2018-02-12 16:49:53', '', 0, 'http://murphylaw.com/?p=21', 2, 'nav_menu_item', '', 0),
(22, 1, '2018-02-06 21:59:01', '2018-02-06 21:59:01', ' ', '', '', 'publish', 'closed', 'closed', '', '22', '', '', '2018-02-12 16:49:53', '2018-02-12 16:49:53', '', 0, 'http://murphylaw.com/?p=22', 4, 'nav_menu_item', '', 0),
(23, 1, '2018-02-06 21:59:01', '2018-02-06 21:59:01', ' ', '', '', 'publish', 'closed', 'closed', '', '23', '', '', '2018-02-12 16:49:53', '2018-02-12 16:49:53', '', 0, 'http://murphylaw.com/?p=23', 13, 'nav_menu_item', '', 0),
(24, 1, '2018-02-06 21:59:01', '2018-02-06 21:59:01', ' ', '', '', 'publish', 'closed', 'closed', '', '24', '', '', '2018-02-12 16:49:53', '2018-02-12 16:49:53', '', 0, 'http://murphylaw.com/?p=24', 17, 'nav_menu_item', '', 0),
(25, 1, '2018-02-06 21:56:59', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-02-06 21:56:59', '0000-00-00 00:00:00', '', 0, 'http://murphylaw.com/?p=25', 1, 'nav_menu_item', '', 0),
(26, 1, '2018-02-06 21:59:01', '2018-02-06 21:59:01', '', 'Practice Area Examples', '', 'publish', 'closed', 'closed', '', '26', '', '', '2018-02-12 16:49:53', '2018-02-12 16:49:53', '', 0, 'http://murphylaw.com/?p=26', 9, 'nav_menu_item', '', 0),
(27, 1, '2018-02-06 21:59:01', '2018-02-06 21:59:01', ' ', '', '', 'publish', 'closed', 'closed', '', '27', '', '', '2018-02-12 16:49:53', '2018-02-12 16:49:53', '', 0, 'http://murphylaw.com/?p=27', 15, 'nav_menu_item', '', 0),
(28, 1, '2018-02-06 21:59:01', '2018-02-06 21:59:01', '', 'Team', '', 'publish', 'closed', 'closed', '', 'team', '', '', '2018-02-12 16:49:53', '2018-02-12 16:49:53', '', 0, 'http://murphylaw.com/?p=28', 3, 'nav_menu_item', '', 0),
(29, 1, '2018-02-06 21:59:01', '2018-02-06 21:59:01', ' ', '', '', 'publish', 'closed', 'closed', '', '29', '', '', '2018-02-12 16:49:53', '2018-02-12 16:49:53', '', 0, 'http://murphylaw.com/?p=29', 5, 'nav_menu_item', '', 0),
(30, 1, '2018-02-06 21:59:01', '2018-02-06 21:59:01', ' ', '', '', 'publish', 'closed', 'closed', '', '30', '', '', '2018-02-12 16:49:53', '2018-02-12 16:49:53', '', 0, 'http://murphylaw.com/?p=30', 6, 'nav_menu_item', '', 0),
(31, 1, '2018-02-06 21:59:01', '2018-02-06 21:59:01', '', 'Practice Areas', '', 'publish', 'closed', 'closed', '', 'practice-areas', '', '', '2018-02-12 16:49:53', '2018-02-12 16:49:53', '', 0, 'http://murphylaw.com/?p=31', 8, 'nav_menu_item', '', 0),
(32, 1, '2018-02-06 21:59:01', '2018-02-06 21:59:01', '', 'Practice Area Examples', '', 'publish', 'closed', 'closed', '', '32', '', '', '2018-02-12 16:49:53', '2018-02-12 16:49:53', '', 0, 'http://murphylaw.com/?p=32', 10, 'nav_menu_item', '', 0),
(33, 1, '2018-02-06 21:59:01', '2018-02-06 21:59:01', '', 'Practice Area Examples', '', 'publish', 'closed', 'closed', '', '33', '', '', '2018-02-12 16:49:53', '2018-02-12 16:49:53', '', 0, 'http://murphylaw.com/?p=33', 11, 'nav_menu_item', '', 0),
(34, 1, '2018-02-07 22:10:33', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-02-07 22:10:33', '0000-00-00 00:00:00', '', 0, 'http://murphylaw.com/?p=34', 0, 'post', '', 0),
(35, 1, '2018-02-07 22:11:56', '2018-02-07 22:11:56', '<h2>Heading Style 2 - Lorem ipsum dolor sit amet, consectetur adipiscing</h2>\r\n		\r\n		<p>Quisque non egestas justo, ac pellentesque dolor. In et diam sagittis, semper lorem id, blandit velit. Integer mattis metus vel nisi commodo porttitor. Aenean commodo commodo facilisis. Nam arcu erat, lacinia sed lacinia quis, pretium eget enim. <a href="">Embedded Link</a>  ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed maximus quam vestibulum imperdiet interdum. Cras rhoncus arcu ornare sapien sollicitudin pulvinar. Vivamus placerat purus sit amet sapien malesuada feugiat. Ut accumsan finibus nunc.</p>\r\n\r\n		<blockquote>Pull Quote : Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc id quam at nisi venenatis tempus eget vel orci neque id euismod.</blockquote>\r\n\r\n		<h3>Heading style 3</h3>\r\n\r\n		<p>Mauris vel tristique mi. Aenean libero tortor, condimentum eget efficitur sed, pulvinar dictum elit. Duis viverra lacus nec leo lacinia fringilla. Ut et est nulla. Vestibulum iaculis quam sapien, finibus luctus arcu convallis vitae. </p>\r\n		\r\n		<ol>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	       Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		</ol>\r\n\r\n		<h4>Heading Style 4</h4>\r\n\r\n		<p>In ullamcorper tempor velit in mattis. Nullam cursus sollicitudin sem, a cursus magna porta ac. In a justo tristique, auctor leo nec, gravida orci. Quisque massa nisi, imperdiet a imperdiet non, rutrum in justo. Cras tempus sollicitudin ipsum, et mattis augue porttitor et.</p>\r\n		\r\n		<ul>\r\n			\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	       	    eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		\r\n		</ul>', 'Practice Areas Two', '', 'publish', 'closed', 'closed', '', 'practice-areas-two', '', '', '2018-02-12 16:47:44', '2018-02-12 16:47:44', '', 0, 'http://murphylaw.com/?page_id=35', 0, 'page', '', 0),
(36, 1, '2018-02-07 22:11:56', '2018-02-07 22:11:56', '', 'Practice Areas Two', '', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2018-02-07 22:11:56', '2018-02-07 22:11:56', '', 35, 'http://murphylaw.com/2018/02/07/35-revision-v1/', 0, 'revision', '', 0),
(37, 1, '2018-02-07 22:12:02', '2018-02-07 22:12:02', '<h2>Heading Style 2 - Lorem ipsum dolor sit amet, consectetur adipiscing</h2>\r\n		\r\n		<p>Quisque non egestas justo, ac pellentesque dolor. In et diam sagittis, semper lorem id, blandit velit. Integer mattis metus vel nisi commodo porttitor. Aenean commodo commodo facilisis. Nam arcu erat, lacinia sed lacinia quis, pretium eget enim. <a href="">Embedded Link</a>  ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed maximus quam vestibulum imperdiet interdum. Cras rhoncus arcu ornare sapien sollicitudin pulvinar. Vivamus placerat purus sit amet sapien malesuada feugiat. Ut accumsan finibus nunc.</p>\r\n\r\n		<blockquote>Pull Quote : Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc id quam at nisi venenatis tempus eget vel orci neque id euismod.</blockquote>\r\n\r\n		<h3>Heading style 3</h3>\r\n\r\n		<p>Mauris vel tristique mi. Aenean libero tortor, condimentum eget efficitur sed, pulvinar dictum elit. Duis viverra lacus nec leo lacinia fringilla. Ut et est nulla. Vestibulum iaculis quam sapien, finibus luctus arcu convallis vitae. </p>\r\n		\r\n		<ol>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	       Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		</ol>\r\n\r\n		<h4>Heading Style 4</h4>\r\n\r\n		<p>In ullamcorper tempor velit in mattis. Nullam cursus sollicitudin sem, a cursus magna porta ac. In a justo tristique, auctor leo nec, gravida orci. Quisque massa nisi, imperdiet a imperdiet non, rutrum in justo. Cras tempus sollicitudin ipsum, et mattis augue porttitor et.</p>\r\n		\r\n		<ul>\r\n			\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	       	    eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		\r\n		</ul>', 'Practice Areas Three', '', 'publish', 'closed', 'closed', '', 'practice-areas-three', '', '', '2018-02-12 16:47:40', '2018-02-12 16:47:40', '', 0, 'http://murphylaw.com/?page_id=37', 0, 'page', '', 0),
(38, 1, '2018-02-07 22:12:02', '2018-02-07 22:12:02', '', 'Practice Areas Three', '', 'inherit', 'closed', 'closed', '', '37-revision-v1', '', '', '2018-02-07 22:12:02', '2018-02-07 22:12:02', '', 37, 'http://murphylaw.com/2018/02/07/37-revision-v1/', 0, 'revision', '', 0),
(39, 1, '2018-02-07 22:12:10', '2018-02-07 22:12:10', '<h2>Heading Style 2 - Lorem ipsum dolor sit amet, consectetur adipiscing</h2>\r\n		\r\n		<p>Quisque non egestas justo, ac pellentesque dolor. In et diam sagittis, semper lorem id, blandit velit. Integer mattis metus vel nisi commodo porttitor. Aenean commodo commodo facilisis. Nam arcu erat, lacinia sed lacinia quis, pretium eget enim. <a href="">Embedded Link</a>  ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed maximus quam vestibulum imperdiet interdum. Cras rhoncus arcu ornare sapien sollicitudin pulvinar. Vivamus placerat purus sit amet sapien malesuada feugiat. Ut accumsan finibus nunc.</p>\r\n\r\n		<blockquote>Pull Quote : Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc id quam at nisi venenatis tempus eget vel orci neque id euismod.</blockquote>\r\n\r\n		<h3>Heading style 3</h3>\r\n\r\n		<p>Mauris vel tristique mi. Aenean libero tortor, condimentum eget efficitur sed, pulvinar dictum elit. Duis viverra lacus nec leo lacinia fringilla. Ut et est nulla. Vestibulum iaculis quam sapien, finibus luctus arcu convallis vitae. </p>\r\n		\r\n		<ol>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	       Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		</ol>\r\n\r\n		<h4>Heading Style 4</h4>\r\n\r\n		<p>In ullamcorper tempor velit in mattis. Nullam cursus sollicitudin sem, a cursus magna porta ac. In a justo tristique, auctor leo nec, gravida orci. Quisque massa nisi, imperdiet a imperdiet non, rutrum in justo. Cras tempus sollicitudin ipsum, et mattis augue porttitor et.</p>\r\n		\r\n		<ul>\r\n			\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	       	    eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		\r\n		</ul>', 'Practice Areas Four', '', 'publish', 'closed', 'closed', '', 'practice-areas-four', '', '', '2018-02-12 16:47:29', '2018-02-12 16:47:29', '', 0, 'http://murphylaw.com/?page_id=39', 0, 'page', '', 0),
(40, 1, '2018-02-07 22:12:10', '2018-02-07 22:12:10', '', 'Practice Areas Four', '', 'inherit', 'closed', 'closed', '', '39-revision-v1', '', '', '2018-02-07 22:12:10', '2018-02-07 22:12:10', '', 39, 'http://murphylaw.com/2018/02/07/39-revision-v1/', 0, 'revision', '', 0),
(41, 1, '2018-02-07 22:12:16', '2018-02-07 22:12:16', '<h2>Heading Style 2 - Lorem ipsum dolor sit amet, consectetur adipiscing</h2>\r\n		\r\n		<p>Quisque non egestas justo, ac pellentesque dolor. In et diam sagittis, semper lorem id, blandit velit. Integer mattis metus vel nisi commodo porttitor. Aenean commodo commodo facilisis. Nam arcu erat, lacinia sed lacinia quis, pretium eget enim. <a href="">Embedded Link</a>  ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed maximus quam vestibulum imperdiet interdum. Cras rhoncus arcu ornare sapien sollicitudin pulvinar. Vivamus placerat purus sit amet sapien malesuada feugiat. Ut accumsan finibus nunc.</p>\r\n\r\n		<blockquote>Pull Quote : Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc id quam at nisi venenatis tempus eget vel orci neque id euismod.</blockquote>\r\n\r\n		<h3>Heading style 3</h3>\r\n\r\n		<p>Mauris vel tristique mi. Aenean libero tortor, condimentum eget efficitur sed, pulvinar dictum elit. Duis viverra lacus nec leo lacinia fringilla. Ut et est nulla. Vestibulum iaculis quam sapien, finibus luctus arcu convallis vitae. </p>\r\n		\r\n		<ol>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	       Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		</ol>\r\n\r\n		<h4>Heading Style 4</h4>\r\n\r\n		<p>In ullamcorper tempor velit in mattis. Nullam cursus sollicitudin sem, a cursus magna porta ac. In a justo tristique, auctor leo nec, gravida orci. Quisque massa nisi, imperdiet a imperdiet non, rutrum in justo. Cras tempus sollicitudin ipsum, et mattis augue porttitor et.</p>\r\n		\r\n		<ul>\r\n			\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	       	    eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		\r\n		</ul>', 'Practice Areas Five', '', 'publish', 'closed', 'closed', '', 'practice-areas-five', '', '', '2018-02-12 16:47:26', '2018-02-12 16:47:26', '', 0, 'http://murphylaw.com/?page_id=41', 0, 'page', '', 0),
(42, 1, '2018-02-07 22:12:16', '2018-02-07 22:12:16', '', 'Practice Areas Five', '', 'inherit', 'closed', 'closed', '', '41-revision-v1', '', '', '2018-02-07 22:12:16', '2018-02-07 22:12:16', '', 41, 'http://murphylaw.com/2018/02/07/41-revision-v1/', 0, 'revision', '', 0),
(43, 1, '2018-02-07 22:12:22', '2018-02-07 22:12:22', '<h2>Heading Style 2 - Lorem ipsum dolor sit amet, consectetur adipiscing</h2>\r\n		\r\n		<p>Quisque non egestas justo, ac pellentesque dolor. In et diam sagittis, semper lorem id, blandit velit. Integer mattis metus vel nisi commodo porttitor. Aenean commodo commodo facilisis. Nam arcu erat, lacinia sed lacinia quis, pretium eget enim. <a href="">Embedded Link</a>  ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed maximus quam vestibulum imperdiet interdum. Cras rhoncus arcu ornare sapien sollicitudin pulvinar. Vivamus placerat purus sit amet sapien malesuada feugiat. Ut accumsan finibus nunc.</p>\r\n\r\n		<blockquote>Pull Quote : Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc id quam at nisi venenatis tempus eget vel orci neque id euismod.</blockquote>\r\n\r\n		<h3>Heading style 3</h3>\r\n\r\n		<p>Mauris vel tristique mi. Aenean libero tortor, condimentum eget efficitur sed, pulvinar dictum elit. Duis viverra lacus nec leo lacinia fringilla. Ut et est nulla. Vestibulum iaculis quam sapien, finibus luctus arcu convallis vitae. </p>\r\n		\r\n		<ol>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	       Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		</ol>\r\n\r\n		<h4>Heading Style 4</h4>\r\n\r\n		<p>In ullamcorper tempor velit in mattis. Nullam cursus sollicitudin sem, a cursus magna porta ac. In a justo tristique, auctor leo nec, gravida orci. Quisque massa nisi, imperdiet a imperdiet non, rutrum in justo. Cras tempus sollicitudin ipsum, et mattis augue porttitor et.</p>\r\n		\r\n		<ul>\r\n			\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	       	    eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		\r\n		</ul>', 'Practice Areas Six', '', 'publish', 'closed', 'closed', '', 'practice-areas-six', '', '', '2018-02-12 16:47:36', '2018-02-12 16:47:36', '', 0, 'http://murphylaw.com/?page_id=43', 0, 'page', '', 0),
(44, 1, '2018-02-07 22:12:22', '2018-02-07 22:12:22', '', 'Practice Areas Six', '', 'inherit', 'closed', 'closed', '', '43-revision-v1', '', '', '2018-02-07 22:12:22', '2018-02-07 22:12:22', '', 43, 'http://murphylaw.com/2018/02/07/43-revision-v1/', 0, 'revision', '', 0),
(45, 1, '2018-02-07 22:12:29', '2018-02-07 22:12:29', '<h2>Heading Style 2 - Lorem ipsum dolor sit amet, consectetur adipiscing</h2>\r\n		\r\n		<p>Quisque non egestas justo, ac pellentesque dolor. In et diam sagittis, semper lorem id, blandit velit. Integer mattis metus vel nisi commodo porttitor. Aenean commodo commodo facilisis. Nam arcu erat, lacinia sed lacinia quis, pretium eget enim. <a href="">Embedded Link</a>  ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed maximus quam vestibulum imperdiet interdum. Cras rhoncus arcu ornare sapien sollicitudin pulvinar. Vivamus placerat purus sit amet sapien malesuada feugiat. Ut accumsan finibus nunc.</p>\r\n\r\n		<blockquote>Pull Quote : Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc id quam at nisi venenatis tempus eget vel orci neque id euismod.</blockquote>\r\n\r\n		<h3>Heading style 3</h3>\r\n\r\n		<p>Mauris vel tristique mi. Aenean libero tortor, condimentum eget efficitur sed, pulvinar dictum elit. Duis viverra lacus nec leo lacinia fringilla. Ut et est nulla. Vestibulum iaculis quam sapien, finibus luctus arcu convallis vitae. </p>\r\n		\r\n		<ol>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	       Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		</ol>\r\n\r\n		<h4>Heading Style 4</h4>\r\n\r\n		<p>In ullamcorper tempor velit in mattis. Nullam cursus sollicitudin sem, a cursus magna porta ac. In a justo tristique, auctor leo nec, gravida orci. Quisque massa nisi, imperdiet a imperdiet non, rutrum in justo. Cras tempus sollicitudin ipsum, et mattis augue porttitor et.</p>\r\n		\r\n		<ul>\r\n			\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	       	    eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		\r\n		</ul>', 'Practice Areas Seven', '', 'publish', 'closed', 'closed', '', 'practice-areas-seven', '', '', '2018-02-12 16:47:33', '2018-02-12 16:47:33', '', 0, 'http://murphylaw.com/?page_id=45', 0, 'page', '', 0),
(46, 1, '2018-02-07 22:12:29', '2018-02-07 22:12:29', '', 'Practice Areas Seven', '', 'inherit', 'closed', 'closed', '', '45-revision-v1', '', '', '2018-02-07 22:12:29', '2018-02-07 22:12:29', '', 45, 'http://murphylaw.com/2018/02/07/45-revision-v1/', 0, 'revision', '', 0),
(47, 1, '2018-02-07 22:12:56', '0000-00-00 00:00:00', '', 'Practice Areas Title', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-02-07 22:12:56', '0000-00-00 00:00:00', '', 0, 'http://murphylaw.com/?p=47', 1, 'nav_menu_item', '', 0),
(48, 1, '2018-02-07 22:15:08', '2018-02-07 22:15:08', ' ', '', '', 'publish', 'closed', 'closed', '', '48', '', '', '2018-02-08 23:19:05', '2018-02-08 23:19:05', '', 0, 'http://murphylaw.com/?p=48', 11, 'nav_menu_item', '', 0),
(49, 1, '2018-02-07 22:15:08', '2018-02-07 22:15:08', ' ', '', '', 'publish', 'closed', 'closed', '', '49', '', '', '2018-02-08 23:19:05', '2018-02-08 23:19:05', '', 0, 'http://murphylaw.com/?p=49', 10, 'nav_menu_item', '', 0),
(50, 1, '2018-02-07 22:15:08', '2018-02-07 22:15:08', ' ', '', '', 'publish', 'closed', 'closed', '', '50', '', '', '2018-02-08 23:19:05', '2018-02-08 23:19:05', '', 0, 'http://murphylaw.com/?p=50', 8, 'nav_menu_item', '', 0),
(51, 1, '2018-02-07 22:15:08', '2018-02-07 22:15:08', ' ', '', '', 'publish', 'closed', 'closed', '', '51', '', '', '2018-02-08 23:19:05', '2018-02-08 23:19:05', '', 0, 'http://murphylaw.com/?p=51', 7, 'nav_menu_item', '', 0),
(52, 1, '2018-02-07 22:15:08', '2018-02-07 22:15:08', ' ', '', '', 'publish', 'closed', 'closed', '', '52', '', '', '2018-02-08 23:19:05', '2018-02-08 23:19:05', '', 0, 'http://murphylaw.com/?p=52', 4, 'nav_menu_item', '', 0),
(53, 1, '2018-02-07 22:15:08', '2018-02-07 22:15:08', ' ', '', '', 'publish', 'closed', 'closed', '', '53', '', '', '2018-02-08 23:19:05', '2018-02-08 23:19:05', '', 0, 'http://murphylaw.com/?p=53', 3, 'nav_menu_item', '', 0),
(54, 1, '2018-02-07 22:15:08', '2018-02-07 22:15:08', ' ', '', '', 'publish', 'closed', 'closed', '', '54', '', '', '2018-02-08 23:19:05', '2018-02-08 23:19:05', '', 0, 'http://murphylaw.com/?p=54', 2, 'nav_menu_item', '', 0),
(55, 1, '2018-02-07 22:15:08', '2018-02-07 22:15:08', '', 'Practice Area Title', '', 'publish', 'closed', 'closed', '', 'practice-area-title', '', '', '2018-02-08 23:19:05', '2018-02-08 23:19:05', '', 0, 'http://murphylaw.com/?p=55', 1, 'nav_menu_item', '', 0),
(56, 1, '2018-02-07 22:15:08', '2018-02-07 22:15:08', '', 'Practice Areas Title', '', 'publish', 'closed', 'closed', '', 'practice-areas-title', '', '', '2018-02-08 23:19:05', '2018-02-08 23:19:05', '', 0, 'http://murphylaw.com/?p=56', 6, 'nav_menu_item', '', 0),
(57, 1, '2018-02-07 22:15:08', '2018-02-07 22:15:08', '', 'Practice Areas Title', '', 'publish', 'closed', 'closed', '', 'practice-areas-title-2', '', '', '2018-02-08 23:19:05', '2018-02-08 23:19:05', '', 0, 'http://murphylaw.com/?p=57', 9, 'nav_menu_item', '', 0),
(58, 1, '2018-02-08 17:50:24', '2018-02-08 17:50:24', '', 'Client Testimonials', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2018-02-08 17:50:24', '2018-02-08 17:50:24', '', 16, 'http://murphylaw.com/2018/02/08/16-revision-v1/', 0, 'revision', '', 0),
(59, 1, '2018-02-08 23:19:05', '2018-02-08 23:19:05', '', 'View All+', '', 'publish', 'closed', 'closed', '', 'view-all', '', '', '2018-02-08 23:19:05', '2018-02-08 23:19:05', '', 0, 'http://murphylaw.com/?p=59', 5, 'nav_menu_item', '', 0),
(60, 1, '2018-02-08 23:20:49', '2018-02-08 23:20:49', '', 'Practice Areas', '', 'publish', 'closed', 'closed', '', 'practice-areas', '', '', '2018-02-08 23:23:27', '2018-02-08 23:23:27', '', 0, 'http://murphylaw.com/?page_id=60', 0, 'page', '', 0),
(61, 1, '2018-02-08 23:20:49', '2018-02-08 23:20:49', '', 'Practice Areas', '', 'inherit', 'closed', 'closed', '', '60-revision-v1', '', '', '2018-02-08 23:20:49', '2018-02-08 23:20:49', '', 60, 'http://murphylaw.com/2018/02/08/60-revision-v1/', 0, 'revision', '', 0),
(62, 1, '2018-02-08 23:23:57', '2018-02-08 23:23:57', '', 'View All+', '', 'publish', 'closed', 'closed', '', 'view-all-2', '', '', '2018-02-12 16:49:53', '2018-02-12 16:49:53', '', 0, 'http://murphylaw.com/?p=62', 12, 'nav_menu_item', '', 0),
(63, 1, '2018-02-09 17:37:13', '2018-02-09 17:37:13', '', 'Video Center', '', 'publish', 'closed', 'closed', '', 'video-center', '', '', '2018-02-09 17:37:13', '2018-02-09 17:37:13', '', 0, 'http://murphylaw.com/?page_id=63', 0, 'page', '', 0),
(64, 1, '2018-02-09 17:37:13', '2018-02-09 17:37:13', '', 'Video Center', '', 'inherit', 'closed', 'closed', '', '63-revision-v1', '', '', '2018-02-09 17:37:13', '2018-02-09 17:37:13', '', 63, 'http://murphylaw.com/2018/02/09/63-revision-v1/', 0, 'revision', '', 0),
(65, 1, '2018-02-09 17:37:34', '2018-02-09 17:37:34', ' ', '', '', 'publish', 'closed', 'closed', '', '65', '', '', '2018-02-12 16:49:53', '2018-02-12 16:49:53', '', 0, 'http://murphylaw.com/?p=65', 14, 'nav_menu_item', '', 0),
(66, 1, '2018-02-09 18:58:59', '2018-02-09 18:58:59', '', 'Meet the Team', '', 'publish', 'closed', 'closed', '', 'meet-the-team', '', '', '2018-02-09 18:58:59', '2018-02-09 18:58:59', '', 0, 'http://murphylaw.com/?page_id=66', 0, 'page', '', 0),
(67, 1, '2018-02-09 18:58:59', '2018-02-09 18:58:59', '', 'Meet the Team', '', 'inherit', 'closed', 'closed', '', '66-revision-v1', '', '', '2018-02-09 18:58:59', '2018-02-09 18:58:59', '', 66, 'http://murphylaw.com/2018/02/09/66-revision-v1/', 0, 'revision', '', 0),
(68, 1, '2018-02-09 18:59:57', '2018-02-09 18:59:57', '', 'View All+', '', 'publish', 'closed', 'closed', '', 'view-all-3', '', '', '2018-02-12 16:49:53', '2018-02-12 16:49:53', '', 0, 'http://murphylaw.com/?p=68', 7, 'nav_menu_item', '', 0),
(69, 1, '2018-02-11 01:01:05', '2018-02-11 01:01:05', '', 'Contact Us', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2018-02-11 01:01:05', '2018-02-11 01:01:05', '', 18, 'http://murphylaw.com/2018/02/11/18-revision-v1/', 0, 'revision', '', 0),
(70, 1, '2018-02-11 02:01:55', '2018-02-11 02:01:55', '', 'Peyton Murphy', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2018-02-11 02:01:55', '2018-02-11 02:01:55', '', 10, 'http://murphylaw.com/2018/02/11/10-revision-v1/', 0, 'revision', '', 0),
(71, 1, '2018-02-11 23:51:39', '2018-02-11 23:51:39', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2018-02-11 23:51:39', '2018-02-11 23:51:39', '', 0, 'http://murphylaw.com/?page_id=71', 0, 'page', '', 0),
(72, 1, '2018-02-11 23:51:39', '2018-02-11 23:51:39', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '71-revision-v1', '', '', '2018-02-11 23:51:39', '2018-02-11 23:51:39', '', 71, 'http://murphylaw.com/2018/02/11/71-revision-v1/', 0, 'revision', '', 0),
(73, 1, '2018-02-11 23:51:59', '2018-02-11 23:51:59', ' ', '', '', 'publish', 'closed', 'closed', '', '73', '', '', '2018-02-12 16:49:53', '2018-02-12 16:49:53', '', 0, 'http://murphylaw.com/?p=73', 16, 'nav_menu_item', '', 0),
(74, 1, '2018-02-11 23:55:26', '2018-02-11 23:55:26', 'Duis ut nisl felis. Phasellus et magna id ipsum placerat mollis nec sed nunc. Donec id urna ac mi commodo ullamcorper nec eu massa. Sed sed malesuada metus, eu malesuada elit. Nullam pretium, eros vel malesuada rhoncus, ligula orci consectetur lacus, ut efficitur metus diam sed ipsum. Sed sit amet mi malesuada, sodales ipsum vel, pretium metus. Mauris mollis felis maximus mauris lacinia venenatis. Aliquam ac risus semper ante dictum vulputate id vitae mauris. Cras efficitur sapien at dolor egestas, id venenatis metus feugiat. Duis condimentum libero lectus, vel faucibus diam vestibulum vel.\r\n\r\nDuis ut nisl felis. Phasellus et magna id ipsum placerat mollis nec sed nunc. Donec id urna ac mi commodo ullamcorper nec eu massa. Sed sed malesuada metus, eu malesuada elit. Nullam pretium, eros vel malesuada rhoncus, ligula orci consectetur lacus, ut efficitur metus diam sed ipsum. Sed sit amet mi malesuada, sodales ipsum vel, pretium metus. Mauris mollis felis maximus mauris lacinia venenatis. Aliquam ac risus semper ante dictum vulputate id vitae mauris. Cras efficitur sapien at dolor egestas, id venenatis metus feugiat. Duis condimentum libero lectus, vel faucibus diam vestibulum vel.\r\n\r\nDuis ut nisl felis. Phasellus et magna id ipsum placerat mollis nec sed nunc. Donec id urna ac mi commodo ullamcorper nec eu massa. Sed sed malesuada metus, eu malesuada elit. Nullam pretium, eros vel malesuada rhoncus, ligula orci consectetur lacus, ut efficitur metus diam sed ipsum. Sed sit amet mi malesuada, sodales ipsum vel, pretium metus. Mauris mollis felis maximus mauris lacinia venenatis. Aliquam ac risus semper ante dictum vulputate id vitae mauris. Cras efficitur sapien at dolor egestas, id venenatis metus feugiat. Duis condimentum libero lectus, vel faucibus diam vestibulum vel.', 'Phasellus sem ante, rutrum efficitur tortor vel. Convallis malesuada erat, curabitur vitae lacus ornare. Proin volutpat pulvinar turpis non porta.', '', 'publish', 'open', 'open', '', 'phasellus-sem-ante-rutrum-efficitur-tortor-vel-convallis-malesuada-erat-curabitur-vitae-lacus-ornare-proin-volutpat-pulvinar-turpis-non-porta', '', '', '2018-02-11 23:55:26', '2018-02-11 23:55:26', '', 0, 'http://murphylaw.com/?p=74', 0, 'post', '', 0),
(75, 1, '2018-02-11 23:55:26', '2018-02-11 23:55:26', 'Duis ut nisl felis. Phasellus et magna id ipsum placerat mollis nec sed nunc. Donec id urna ac mi commodo ullamcorper nec eu massa. Sed sed malesuada metus, eu malesuada elit. Nullam pretium, eros vel malesuada rhoncus, ligula orci consectetur lacus, ut efficitur metus diam sed ipsum. Sed sit amet mi malesuada, sodales ipsum vel, pretium metus. Mauris mollis felis maximus mauris lacinia venenatis. Aliquam ac risus semper ante dictum vulputate id vitae mauris. Cras efficitur sapien at dolor egestas, id venenatis metus feugiat. Duis condimentum libero lectus, vel faucibus diam vestibulum vel.\r\n\r\nDuis ut nisl felis. Phasellus et magna id ipsum placerat mollis nec sed nunc. Donec id urna ac mi commodo ullamcorper nec eu massa. Sed sed malesuada metus, eu malesuada elit. Nullam pretium, eros vel malesuada rhoncus, ligula orci consectetur lacus, ut efficitur metus diam sed ipsum. Sed sit amet mi malesuada, sodales ipsum vel, pretium metus. Mauris mollis felis maximus mauris lacinia venenatis. Aliquam ac risus semper ante dictum vulputate id vitae mauris. Cras efficitur sapien at dolor egestas, id venenatis metus feugiat. Duis condimentum libero lectus, vel faucibus diam vestibulum vel.\r\n\r\nDuis ut nisl felis. Phasellus et magna id ipsum placerat mollis nec sed nunc. Donec id urna ac mi commodo ullamcorper nec eu massa. Sed sed malesuada metus, eu malesuada elit. Nullam pretium, eros vel malesuada rhoncus, ligula orci consectetur lacus, ut efficitur metus diam sed ipsum. Sed sit amet mi malesuada, sodales ipsum vel, pretium metus. Mauris mollis felis maximus mauris lacinia venenatis. Aliquam ac risus semper ante dictum vulputate id vitae mauris. Cras efficitur sapien at dolor egestas, id venenatis metus feugiat. Duis condimentum libero lectus, vel faucibus diam vestibulum vel.', 'Phasellus sem ante, rutrum efficitur tortor vel. Convallis malesuada erat, curabitur vitae lacus ornare. Proin volutpat pulvinar turpis non porta.', '', 'inherit', 'closed', 'closed', '', '74-revision-v1', '', '', '2018-02-11 23:55:26', '2018-02-11 23:55:26', '', 74, 'http://murphylaw.com/2018/02/11/74-revision-v1/', 0, 'revision', '', 0),
(76, 1, '2018-02-11 23:55:34', '2018-02-11 23:55:34', 'Duis ut nisl felis. Phasellus et magna id ipsum placerat mollis nec sed nunc. Donec id urna ac mi commodo ullamcorper nec eu massa. Sed sed malesuada metus, eu malesuada elit. Nullam pretium, eros vel malesuada rhoncus, ligula orci consectetur lacus, ut efficitur metus diam sed ipsum. Sed sit amet mi malesuada, sodales ipsum vel, pretium metus. Mauris mollis felis maximus mauris lacinia venenatis. Aliquam ac risus semper ante dictum vulputate id vitae mauris. Cras efficitur sapien at dolor egestas, id venenatis metus feugiat. Duis condimentum libero lectus, vel faucibus diam vestibulum vel.\r\n\r\nDuis ut nisl felis. Phasellus et magna id ipsum placerat mollis nec sed nunc. Donec id urna ac mi commodo ullamcorper nec eu massa. Sed sed malesuada metus, eu malesuada elit. Nullam pretium, eros vel malesuada rhoncus, ligula orci consectetur lacus, ut efficitur metus diam sed ipsum. Sed sit amet mi malesuada, sodales ipsum vel, pretium metus. Mauris mollis felis maximus mauris lacinia venenatis. Aliquam ac risus semper ante dictum vulputate id vitae mauris. Cras efficitur sapien at dolor egestas, id venenatis metus feugiat. Duis condimentum libero lectus, vel faucibus diam vestibulum vel.\r\n\r\nDuis ut nisl felis. Phasellus et magna id ipsum placerat mollis nec sed nunc. Donec id urna ac mi commodo ullamcorper nec eu massa. Sed sed malesuada metus, eu malesuada elit. Nullam pretium, eros vel malesuada rhoncus, ligula orci consectetur lacus, ut efficitur metus diam sed ipsum. Sed sit amet mi malesuada, sodales ipsum vel, pretium metus. Mauris mollis felis maximus mauris lacinia venenatis. Aliquam ac risus semper ante dictum vulputate id vitae mauris. Cras efficitur sapien at dolor egestas, id venenatis metus feugiat. Duis condimentum libero lectus, vel faucibus diam vestibulum vel.', 'Phasellus sem ante, rutrum efficitur tortor vel. Convallis malesuada erat, curabitur vitae lacus ornare. Proin volutpat pulvinar turpis non porta.  Copy', '', 'publish', 'open', 'open', '', 'phasellus-sem-ante-rutrum-efficitur-tortor-vel-convallis-malesuada-erat-curabitur-vitae-lacus-ornare-proin-volutpat-pulvinar-turpis-non-porta-copy', '', '', '2018-02-11 23:55:34', '2018-02-11 23:55:34', '', 0, 'http://murphylaw.com/2018/02/11/phasellus-sem-ante-rutrum-efficitur-tortor-vel-convallis-malesuada-erat-curabitur-vitae-lacus-ornare-proin-volutpat-pulvinar-turpis-non-porta-copy/', 0, 'post', '', 0),
(77, 1, '2018-02-11 23:55:38', '2018-02-11 23:55:38', 'Duis ut nisl felis. Phasellus et magna id ipsum placerat mollis nec sed nunc. Donec id urna ac mi commodo ullamcorper nec eu massa. Sed sed malesuada metus, eu malesuada elit. Nullam pretium, eros vel malesuada rhoncus, ligula orci consectetur lacus, ut efficitur metus diam sed ipsum. Sed sit amet mi malesuada, sodales ipsum vel, pretium metus. Mauris mollis felis maximus mauris lacinia venenatis. Aliquam ac risus semper ante dictum vulputate id vitae mauris. Cras efficitur sapien at dolor egestas, id venenatis metus feugiat. Duis condimentum libero lectus, vel faucibus diam vestibulum vel.\r\n\r\nDuis ut nisl felis. Phasellus et magna id ipsum placerat mollis nec sed nunc. Donec id urna ac mi commodo ullamcorper nec eu massa. Sed sed malesuada metus, eu malesuada elit. Nullam pretium, eros vel malesuada rhoncus, ligula orci consectetur lacus, ut efficitur metus diam sed ipsum. Sed sit amet mi malesuada, sodales ipsum vel, pretium metus. Mauris mollis felis maximus mauris lacinia venenatis. Aliquam ac risus semper ante dictum vulputate id vitae mauris. Cras efficitur sapien at dolor egestas, id venenatis metus feugiat. Duis condimentum libero lectus, vel faucibus diam vestibulum vel.\r\n\r\nDuis ut nisl felis. Phasellus et magna id ipsum placerat mollis nec sed nunc. Donec id urna ac mi commodo ullamcorper nec eu massa. Sed sed malesuada metus, eu malesuada elit. Nullam pretium, eros vel malesuada rhoncus, ligula orci consectetur lacus, ut efficitur metus diam sed ipsum. Sed sit amet mi malesuada, sodales ipsum vel, pretium metus. Mauris mollis felis maximus mauris lacinia venenatis. Aliquam ac risus semper ante dictum vulputate id vitae mauris. Cras efficitur sapien at dolor egestas, id venenatis metus feugiat. Duis condimentum libero lectus, vel faucibus diam vestibulum vel.', 'Phasellus sem ante, rutrum efficitur tortor vel. Convallis malesuada erat, curabitur vitae lacus ornare. Proin volutpat pulvinar turpis non porta.  Copy  Copy', '', 'publish', 'open', 'open', '', 'phasellus-sem-ante-rutrum-efficitur-tortor-vel-convallis-malesuada-erat-curabitur-vitae-lacus-ornare-proin-volutpat-pulvinar-turpis-non-porta-copy-copy', '', '', '2018-02-11 23:55:38', '2018-02-11 23:55:38', '', 0, 'http://murphylaw.com/2018/02/11/phasellus-sem-ante-rutrum-efficitur-tortor-vel-convallis-malesuada-erat-curabitur-vitae-lacus-ornare-proin-volutpat-pulvinar-turpis-non-porta-copy-copy/', 0, 'post', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(78, 1, '2018-02-11 23:55:41', '2018-02-11 23:55:41', 'Duis ut nisl felis. Phasellus et magna id ipsum placerat mollis nec sed nunc. Donec id urna ac mi commodo ullamcorper nec eu massa. Sed sed malesuada metus, eu malesuada elit. Nullam pretium, eros vel malesuada rhoncus, ligula orci consectetur lacus, ut efficitur metus diam sed ipsum. Sed sit amet mi malesuada, sodales ipsum vel, pretium metus. Mauris mollis felis maximus mauris lacinia venenatis. Aliquam ac risus semper ante dictum vulputate id vitae mauris. Cras efficitur sapien at dolor egestas, id venenatis metus feugiat. Duis condimentum libero lectus, vel faucibus diam vestibulum vel.\r\n\r\nDuis ut nisl felis. Phasellus et magna id ipsum placerat mollis nec sed nunc. Donec id urna ac mi commodo ullamcorper nec eu massa. Sed sed malesuada metus, eu malesuada elit. Nullam pretium, eros vel malesuada rhoncus, ligula orci consectetur lacus, ut efficitur metus diam sed ipsum. Sed sit amet mi malesuada, sodales ipsum vel, pretium metus. Mauris mollis felis maximus mauris lacinia venenatis. Aliquam ac risus semper ante dictum vulputate id vitae mauris. Cras efficitur sapien at dolor egestas, id venenatis metus feugiat. Duis condimentum libero lectus, vel faucibus diam vestibulum vel.\r\n\r\nDuis ut nisl felis. Phasellus et magna id ipsum placerat mollis nec sed nunc. Donec id urna ac mi commodo ullamcorper nec eu massa. Sed sed malesuada metus, eu malesuada elit. Nullam pretium, eros vel malesuada rhoncus, ligula orci consectetur lacus, ut efficitur metus diam sed ipsum. Sed sit amet mi malesuada, sodales ipsum vel, pretium metus. Mauris mollis felis maximus mauris lacinia venenatis. Aliquam ac risus semper ante dictum vulputate id vitae mauris. Cras efficitur sapien at dolor egestas, id venenatis metus feugiat. Duis condimentum libero lectus, vel faucibus diam vestibulum vel.', 'Phasellus sem ante, rutrum efficitur tortor vel. Convallis malesuada erat, curabitur vitae lacus ornare. Proin volutpat pulvinar turpis non porta.  Copy  Copy  Copy', '', 'publish', 'open', 'open', '', 'phasellus-sem-ante-rutrum-efficitur-tortor-vel-convallis-malesuada-erat-curabitur-vitae-lacus-ornare-proin-volutpat-pulvinar-turpis-non-porta-copy-copy-copy', '', '', '2018-02-11 23:55:41', '2018-02-11 23:55:41', '', 0, 'http://murphylaw.com/2018/02/11/phasellus-sem-ante-rutrum-efficitur-tortor-vel-convallis-malesuada-erat-curabitur-vitae-lacus-ornare-proin-volutpat-pulvinar-turpis-non-porta-copy-copy-copy/', 0, 'post', '', 0),
(79, 1, '2018-02-11 23:55:44', '2018-02-11 23:55:44', 'Duis ut nisl felis. Phasellus et magna id ipsum placerat mollis nec sed nunc. Donec id urna ac mi commodo ullamcorper nec eu massa. Sed sed malesuada metus, eu malesuada elit. Nullam pretium, eros vel malesuada rhoncus, ligula orci consectetur lacus, ut efficitur metus diam sed ipsum. Sed sit amet mi malesuada, sodales ipsum vel, pretium metus. Mauris mollis felis maximus mauris lacinia venenatis. Aliquam ac risus semper ante dictum vulputate id vitae mauris. Cras efficitur sapien at dolor egestas, id venenatis metus feugiat. Duis condimentum libero lectus, vel faucibus diam vestibulum vel.\r\n\r\nDuis ut nisl felis. Phasellus et magna id ipsum placerat mollis nec sed nunc. Donec id urna ac mi commodo ullamcorper nec eu massa. Sed sed malesuada metus, eu malesuada elit. Nullam pretium, eros vel malesuada rhoncus, ligula orci consectetur lacus, ut efficitur metus diam sed ipsum. Sed sit amet mi malesuada, sodales ipsum vel, pretium metus. Mauris mollis felis maximus mauris lacinia venenatis. Aliquam ac risus semper ante dictum vulputate id vitae mauris. Cras efficitur sapien at dolor egestas, id venenatis metus feugiat. Duis condimentum libero lectus, vel faucibus diam vestibulum vel.\r\n\r\nDuis ut nisl felis. Phasellus et magna id ipsum placerat mollis nec sed nunc. Donec id urna ac mi commodo ullamcorper nec eu massa. Sed sed malesuada metus, eu malesuada elit. Nullam pretium, eros vel malesuada rhoncus, ligula orci consectetur lacus, ut efficitur metus diam sed ipsum. Sed sit amet mi malesuada, sodales ipsum vel, pretium metus. Mauris mollis felis maximus mauris lacinia venenatis. Aliquam ac risus semper ante dictum vulputate id vitae mauris. Cras efficitur sapien at dolor egestas, id venenatis metus feugiat. Duis condimentum libero lectus, vel faucibus diam vestibulum vel.', 'Phasellus sem ante, rutrum efficitur tortor vel. Convallis malesuada erat, curabitur vitae lacus ornare. Proin volutpat pulvinar turpis non porta.  Copy  Copy  Copy  Copy', '', 'publish', 'open', 'open', '', 'phasellus-sem-ante-rutrum-efficitur-tortor-vel-convallis-malesuada-erat-curabitur-vitae-lacus-ornare-proin-volutpat-pulvinar-turpis-non-porta-copy-copy-copy-copy', '', '', '2018-02-12 01:52:59', '2018-02-12 01:52:59', '', 0, 'http://murphylaw.com/2018/02/11/phasellus-sem-ante-rutrum-efficitur-tortor-vel-convallis-malesuada-erat-curabitur-vitae-lacus-ornare-proin-volutpat-pulvinar-turpis-non-porta-copy-copy-copy-copy/', 0, 'post', '', 0),
(80, 1, '2018-02-12 01:52:49', '2018-02-12 01:52:49', 'Duis ut nisl felis. Phasellus et magna id ipsum placerat mollis nec sed nunc. Donec id urna ac mi commodo ullamcorper nec eu massa. Sed sed malesuada metus, eu malesuada elit. Nullam pretium, eros vel malesuada rhoncus, ligula orci consectetur lacus, ut efficitur metus diam sed ipsum. Sed sit amet mi malesuada, sodales ipsum vel, pretium metus. Mauris mollis felis maximus mauris lacinia venenatis. Aliquam ac risus semper ante dictum vulputate id vitae mauris. Cras efficitur sapien at dolor egestas, id venenatis metus feugiat. Duis condimentum libero lectus, vel faucibus diam vestibulum vel.\r\n\r\nDuis ut nisl felis. Phasellus et magna id ipsum placerat mollis nec sed nunc. Donec id urna ac mi commodo ullamcorper nec eu massa. Sed sed malesuada metus, eu malesuada elit. Nullam pretium, eros vel malesuada rhoncus, ligula orci consectetur lacus, ut efficitur metus diam sed ipsum. Sed sit amet mi malesuada, sodales ipsum vel, pretium metus. Mauris mollis felis maximus mauris lacinia venenatis. Aliquam ac risus semper ante dictum vulputate id vitae mauris. Cras efficitur sapien at dolor egestas, id venenatis metus feugiat. Duis condimentum libero lectus, vel faucibus diam vestibulum vel.\r\n\r\nDuis ut nisl felis. Phasellus et magna id ipsum placerat mollis nec sed nunc. Donec id urna ac mi commodo ullamcorper nec eu massa. Sed sed malesuada metus, eu malesuada elit. Nullam pretium, eros vel malesuada rhoncus, ligula orci consectetur lacus, ut efficitur metus diam sed ipsum. Sed sit amet mi malesuada, sodales ipsum vel, pretium metus. Mauris mollis felis maximus mauris lacinia venenatis. Aliquam ac risus semper ante dictum vulputate id vitae mauris. Cras efficitur sapien at dolor egestas, id venenatis metus feugiat. Duis condimentum libero lectus, vel faucibus diam vestibulum vel.', 'Phasellus sem ante, rutrum efficitur tortor vel. Convallis malesuada erat, curabitur vitae lacus ornare. Proin volutpat pulvinar turpis non porta.  Copy  Copy  Copy  Copy', '', 'inherit', 'closed', 'closed', '', '79-revision-v1', '', '', '2018-02-12 01:52:49', '2018-02-12 01:52:49', '', 79, 'http://murphylaw.com/2018/02/12/79-revision-v1/', 0, 'revision', '', 0),
(81, 1, '2018-02-12 16:44:58', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-02-12 16:44:58', '0000-00-00 00:00:00', '', 0, 'http://murphylaw.com/?p=81', 0, 'post', '', 0),
(82, 1, '2018-02-12 16:45:39', '2018-02-12 16:45:39', 'Thanks for contacting us! We will get back to you shortly.', 'Thank You', '', 'publish', 'closed', 'closed', '', 'thank-you', '', '', '2018-02-12 16:45:39', '2018-02-12 16:45:39', '', 0, 'http://murphylaw.com/?page_id=82', 0, 'page', '', 0),
(83, 1, '2018-02-12 16:45:39', '2018-02-12 16:45:39', 'Thanks for contacting us! We will get back to you shortly.', 'Thank You', '', 'inherit', 'closed', 'closed', '', '82-revision-v1', '', '', '2018-02-12 16:45:39', '2018-02-12 16:45:39', '', 82, 'http://murphylaw.com/2018/02/12/82-revision-v1/', 0, 'revision', '', 0),
(84, 1, '2018-02-12 16:47:22', '2018-02-12 16:47:22', '<h2>Heading Style 2 - Lorem ipsum dolor sit amet, consectetur adipiscing</h2>\r\n		\r\n		<p>Quisque non egestas justo, ac pellentesque dolor. In et diam sagittis, semper lorem id, blandit velit. Integer mattis metus vel nisi commodo porttitor. Aenean commodo commodo facilisis. Nam arcu erat, lacinia sed lacinia quis, pretium eget enim. <a href="">Embedded Link</a>  ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed maximus quam vestibulum imperdiet interdum. Cras rhoncus arcu ornare sapien sollicitudin pulvinar. Vivamus placerat purus sit amet sapien malesuada feugiat. Ut accumsan finibus nunc.</p>\r\n\r\n		<blockquote>Pull Quote : Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc id quam at nisi venenatis tempus eget vel orci neque id euismod.</blockquote>\r\n\r\n		<h3>Heading style 3</h3>\r\n\r\n		<p>Mauris vel tristique mi. Aenean libero tortor, condimentum eget efficitur sed, pulvinar dictum elit. Duis viverra lacus nec leo lacinia fringilla. Ut et est nulla. Vestibulum iaculis quam sapien, finibus luctus arcu convallis vitae. </p>\r\n		\r\n		<ol>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	       Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		</ol>\r\n\r\n		<h4>Heading Style 4</h4>\r\n\r\n		<p>In ullamcorper tempor velit in mattis. Nullam cursus sollicitudin sem, a cursus magna porta ac. In a justo tristique, auctor leo nec, gravida orci. Quisque massa nisi, imperdiet a imperdiet non, rutrum in justo. Cras tempus sollicitudin ipsum, et mattis augue porttitor et.</p>\r\n		\r\n		<ul>\r\n			\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	       	    eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		\r\n		</ul>', 'Practice Area Examples', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2018-02-12 16:47:22', '2018-02-12 16:47:22', '', 12, 'http://murphylaw.com/2018/02/12/12-revision-v1/', 0, 'revision', '', 0),
(85, 1, '2018-02-12 16:47:26', '2018-02-12 16:47:26', '<h2>Heading Style 2 - Lorem ipsum dolor sit amet, consectetur adipiscing</h2>\r\n		\r\n		<p>Quisque non egestas justo, ac pellentesque dolor. In et diam sagittis, semper lorem id, blandit velit. Integer mattis metus vel nisi commodo porttitor. Aenean commodo commodo facilisis. Nam arcu erat, lacinia sed lacinia quis, pretium eget enim. <a href="">Embedded Link</a>  ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed maximus quam vestibulum imperdiet interdum. Cras rhoncus arcu ornare sapien sollicitudin pulvinar. Vivamus placerat purus sit amet sapien malesuada feugiat. Ut accumsan finibus nunc.</p>\r\n\r\n		<blockquote>Pull Quote : Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc id quam at nisi venenatis tempus eget vel orci neque id euismod.</blockquote>\r\n\r\n		<h3>Heading style 3</h3>\r\n\r\n		<p>Mauris vel tristique mi. Aenean libero tortor, condimentum eget efficitur sed, pulvinar dictum elit. Duis viverra lacus nec leo lacinia fringilla. Ut et est nulla. Vestibulum iaculis quam sapien, finibus luctus arcu convallis vitae. </p>\r\n		\r\n		<ol>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	       Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		</ol>\r\n\r\n		<h4>Heading Style 4</h4>\r\n\r\n		<p>In ullamcorper tempor velit in mattis. Nullam cursus sollicitudin sem, a cursus magna porta ac. In a justo tristique, auctor leo nec, gravida orci. Quisque massa nisi, imperdiet a imperdiet non, rutrum in justo. Cras tempus sollicitudin ipsum, et mattis augue porttitor et.</p>\r\n		\r\n		<ul>\r\n			\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	       	    eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		\r\n		</ul>', 'Practice Areas Five', '', 'inherit', 'closed', 'closed', '', '41-revision-v1', '', '', '2018-02-12 16:47:26', '2018-02-12 16:47:26', '', 41, 'http://murphylaw.com/2018/02/12/41-revision-v1/', 0, 'revision', '', 0),
(86, 1, '2018-02-12 16:47:29', '2018-02-12 16:47:29', '<h2>Heading Style 2 - Lorem ipsum dolor sit amet, consectetur adipiscing</h2>\r\n		\r\n		<p>Quisque non egestas justo, ac pellentesque dolor. In et diam sagittis, semper lorem id, blandit velit. Integer mattis metus vel nisi commodo porttitor. Aenean commodo commodo facilisis. Nam arcu erat, lacinia sed lacinia quis, pretium eget enim. <a href="">Embedded Link</a>  ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed maximus quam vestibulum imperdiet interdum. Cras rhoncus arcu ornare sapien sollicitudin pulvinar. Vivamus placerat purus sit amet sapien malesuada feugiat. Ut accumsan finibus nunc.</p>\r\n\r\n		<blockquote>Pull Quote : Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc id quam at nisi venenatis tempus eget vel orci neque id euismod.</blockquote>\r\n\r\n		<h3>Heading style 3</h3>\r\n\r\n		<p>Mauris vel tristique mi. Aenean libero tortor, condimentum eget efficitur sed, pulvinar dictum elit. Duis viverra lacus nec leo lacinia fringilla. Ut et est nulla. Vestibulum iaculis quam sapien, finibus luctus arcu convallis vitae. </p>\r\n		\r\n		<ol>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	       Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		</ol>\r\n\r\n		<h4>Heading Style 4</h4>\r\n\r\n		<p>In ullamcorper tempor velit in mattis. Nullam cursus sollicitudin sem, a cursus magna porta ac. In a justo tristique, auctor leo nec, gravida orci. Quisque massa nisi, imperdiet a imperdiet non, rutrum in justo. Cras tempus sollicitudin ipsum, et mattis augue porttitor et.</p>\r\n		\r\n		<ul>\r\n			\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	       	    eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		\r\n		</ul>', 'Practice Areas Four', '', 'inherit', 'closed', 'closed', '', '39-revision-v1', '', '', '2018-02-12 16:47:29', '2018-02-12 16:47:29', '', 39, 'http://murphylaw.com/2018/02/12/39-revision-v1/', 0, 'revision', '', 0),
(87, 1, '2018-02-12 16:47:33', '2018-02-12 16:47:33', '<h2>Heading Style 2 - Lorem ipsum dolor sit amet, consectetur adipiscing</h2>\r\n		\r\n		<p>Quisque non egestas justo, ac pellentesque dolor. In et diam sagittis, semper lorem id, blandit velit. Integer mattis metus vel nisi commodo porttitor. Aenean commodo commodo facilisis. Nam arcu erat, lacinia sed lacinia quis, pretium eget enim. <a href="">Embedded Link</a>  ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed maximus quam vestibulum imperdiet interdum. Cras rhoncus arcu ornare sapien sollicitudin pulvinar. Vivamus placerat purus sit amet sapien malesuada feugiat. Ut accumsan finibus nunc.</p>\r\n\r\n		<blockquote>Pull Quote : Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc id quam at nisi venenatis tempus eget vel orci neque id euismod.</blockquote>\r\n\r\n		<h3>Heading style 3</h3>\r\n\r\n		<p>Mauris vel tristique mi. Aenean libero tortor, condimentum eget efficitur sed, pulvinar dictum elit. Duis viverra lacus nec leo lacinia fringilla. Ut et est nulla. Vestibulum iaculis quam sapien, finibus luctus arcu convallis vitae. </p>\r\n		\r\n		<ol>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	       Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		</ol>\r\n\r\n		<h4>Heading Style 4</h4>\r\n\r\n		<p>In ullamcorper tempor velit in mattis. Nullam cursus sollicitudin sem, a cursus magna porta ac. In a justo tristique, auctor leo nec, gravida orci. Quisque massa nisi, imperdiet a imperdiet non, rutrum in justo. Cras tempus sollicitudin ipsum, et mattis augue porttitor et.</p>\r\n		\r\n		<ul>\r\n			\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	       	    eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		\r\n		</ul>', 'Practice Areas Seven', '', 'inherit', 'closed', 'closed', '', '45-revision-v1', '', '', '2018-02-12 16:47:33', '2018-02-12 16:47:33', '', 45, 'http://murphylaw.com/2018/02/12/45-revision-v1/', 0, 'revision', '', 0),
(88, 1, '2018-02-12 16:47:36', '2018-02-12 16:47:36', '<h2>Heading Style 2 - Lorem ipsum dolor sit amet, consectetur adipiscing</h2>\r\n		\r\n		<p>Quisque non egestas justo, ac pellentesque dolor. In et diam sagittis, semper lorem id, blandit velit. Integer mattis metus vel nisi commodo porttitor. Aenean commodo commodo facilisis. Nam arcu erat, lacinia sed lacinia quis, pretium eget enim. <a href="">Embedded Link</a>  ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed maximus quam vestibulum imperdiet interdum. Cras rhoncus arcu ornare sapien sollicitudin pulvinar. Vivamus placerat purus sit amet sapien malesuada feugiat. Ut accumsan finibus nunc.</p>\r\n\r\n		<blockquote>Pull Quote : Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc id quam at nisi venenatis tempus eget vel orci neque id euismod.</blockquote>\r\n\r\n		<h3>Heading style 3</h3>\r\n\r\n		<p>Mauris vel tristique mi. Aenean libero tortor, condimentum eget efficitur sed, pulvinar dictum elit. Duis viverra lacus nec leo lacinia fringilla. Ut et est nulla. Vestibulum iaculis quam sapien, finibus luctus arcu convallis vitae. </p>\r\n		\r\n		<ol>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	       Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		</ol>\r\n\r\n		<h4>Heading Style 4</h4>\r\n\r\n		<p>In ullamcorper tempor velit in mattis. Nullam cursus sollicitudin sem, a cursus magna porta ac. In a justo tristique, auctor leo nec, gravida orci. Quisque massa nisi, imperdiet a imperdiet non, rutrum in justo. Cras tempus sollicitudin ipsum, et mattis augue porttitor et.</p>\r\n		\r\n		<ul>\r\n			\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	       	    eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		\r\n		</ul>', 'Practice Areas Six', '', 'inherit', 'closed', 'closed', '', '43-revision-v1', '', '', '2018-02-12 16:47:36', '2018-02-12 16:47:36', '', 43, 'http://murphylaw.com/2018/02/12/43-revision-v1/', 0, 'revision', '', 0),
(89, 1, '2018-02-12 16:47:40', '2018-02-12 16:47:40', '<h2>Heading Style 2 - Lorem ipsum dolor sit amet, consectetur adipiscing</h2>\r\n		\r\n		<p>Quisque non egestas justo, ac pellentesque dolor. In et diam sagittis, semper lorem id, blandit velit. Integer mattis metus vel nisi commodo porttitor. Aenean commodo commodo facilisis. Nam arcu erat, lacinia sed lacinia quis, pretium eget enim. <a href="">Embedded Link</a>  ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed maximus quam vestibulum imperdiet interdum. Cras rhoncus arcu ornare sapien sollicitudin pulvinar. Vivamus placerat purus sit amet sapien malesuada feugiat. Ut accumsan finibus nunc.</p>\r\n\r\n		<blockquote>Pull Quote : Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc id quam at nisi venenatis tempus eget vel orci neque id euismod.</blockquote>\r\n\r\n		<h3>Heading style 3</h3>\r\n\r\n		<p>Mauris vel tristique mi. Aenean libero tortor, condimentum eget efficitur sed, pulvinar dictum elit. Duis viverra lacus nec leo lacinia fringilla. Ut et est nulla. Vestibulum iaculis quam sapien, finibus luctus arcu convallis vitae. </p>\r\n		\r\n		<ol>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	       Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		</ol>\r\n\r\n		<h4>Heading Style 4</h4>\r\n\r\n		<p>In ullamcorper tempor velit in mattis. Nullam cursus sollicitudin sem, a cursus magna porta ac. In a justo tristique, auctor leo nec, gravida orci. Quisque massa nisi, imperdiet a imperdiet non, rutrum in justo. Cras tempus sollicitudin ipsum, et mattis augue porttitor et.</p>\r\n		\r\n		<ul>\r\n			\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	       	    eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		\r\n		</ul>', 'Practice Areas Three', '', 'inherit', 'closed', 'closed', '', '37-revision-v1', '', '', '2018-02-12 16:47:40', '2018-02-12 16:47:40', '', 37, 'http://murphylaw.com/2018/02/12/37-revision-v1/', 0, 'revision', '', 0),
(90, 1, '2018-02-12 16:47:44', '2018-02-12 16:47:44', '<h2>Heading Style 2 - Lorem ipsum dolor sit amet, consectetur adipiscing</h2>\r\n		\r\n		<p>Quisque non egestas justo, ac pellentesque dolor. In et diam sagittis, semper lorem id, blandit velit. Integer mattis metus vel nisi commodo porttitor. Aenean commodo commodo facilisis. Nam arcu erat, lacinia sed lacinia quis, pretium eget enim. <a href="">Embedded Link</a>  ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed maximus quam vestibulum imperdiet interdum. Cras rhoncus arcu ornare sapien sollicitudin pulvinar. Vivamus placerat purus sit amet sapien malesuada feugiat. Ut accumsan finibus nunc.</p>\r\n\r\n		<blockquote>Pull Quote : Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc id quam at nisi venenatis tempus eget vel orci neque id euismod.</blockquote>\r\n\r\n		<h3>Heading style 3</h3>\r\n\r\n		<p>Mauris vel tristique mi. Aenean libero tortor, condimentum eget efficitur sed, pulvinar dictum elit. Duis viverra lacus nec leo lacinia fringilla. Ut et est nulla. Vestibulum iaculis quam sapien, finibus luctus arcu convallis vitae. </p>\r\n		\r\n		<ol>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	       Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		</ol>\r\n\r\n		<h4>Heading Style 4</h4>\r\n\r\n		<p>In ullamcorper tempor velit in mattis. Nullam cursus sollicitudin sem, a cursus magna porta ac. In a justo tristique, auctor leo nec, gravida orci. Quisque massa nisi, imperdiet a imperdiet non, rutrum in justo. Cras tempus sollicitudin ipsum, et mattis augue porttitor et.</p>\r\n		\r\n		<ul>\r\n			\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	       	    eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		\r\n		</ul>', 'Practice Areas Two', '', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2018-02-12 16:47:44', '2018-02-12 16:47:44', '', 35, 'http://murphylaw.com/2018/02/12/35-revision-v1/', 0, 'revision', '', 0),
(91, 1, '2018-02-12 16:49:00', '2018-02-12 16:49:00', '<h2>Heading Style 2 - Lorem ipsum dolor sit amet, consectetur adipiscing</h2>\r\n		\r\n		<p>Quisque non egestas justo, ac pellentesque dolor. In et diam sagittis, semper lorem id, blandit velit. Integer mattis metus vel nisi commodo porttitor. Aenean commodo commodo facilisis. Nam arcu erat, lacinia sed lacinia quis, pretium eget enim. <a href="">Embedded Link</a>  ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed maximus quam vestibulum imperdiet interdum. Cras rhoncus arcu ornare sapien sollicitudin pulvinar. Vivamus placerat purus sit amet sapien malesuada feugiat. Ut accumsan finibus nunc.</p>\r\n\r\n		<blockquote>Pull Quote : Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc id quam at nisi venenatis tempus eget vel orci neque id euismod.</blockquote>\r\n\r\n		<h3>Heading style 3</h3>\r\n\r\n		<p>Mauris vel tristique mi. Aenean libero tortor, condimentum eget efficitur sed, pulvinar dictum elit. Duis viverra lacus nec leo lacinia fringilla. Ut et est nulla. Vestibulum iaculis quam sapien, finibus luctus arcu convallis vitae. </p>\r\n		\r\n		<ol>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	       Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		</ol>\r\n\r\n		<h4>Heading Style 4</h4>\r\n\r\n		<p>In ullamcorper tempor velit in mattis. Nullam cursus sollicitudin sem, a cursus magna porta ac. In a justo tristique, auctor leo nec, gravida orci. Quisque massa nisi, imperdiet a imperdiet non, rutrum in justo. Cras tempus sollicitudin ipsum, et mattis augue porttitor et.</p>\r\n		\r\n		<ul>\r\n			\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	       	    eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		\r\n		</ul>', 'H1 - Car Accident Lawyers', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2018-02-12 16:49:00', '2018-02-12 16:49:00', '', 12, 'http://murphylaw.com/2018/02/12/12-revision-v1/', 0, 'revision', '', 0),
(92, 1, '2018-02-12 17:20:25', '2018-02-12 17:20:25', '<h2>Heading Style 2 - Lorem ipsum dolor sit amet, consectetur adipiscing</h2>\r\n		\r\n		<p>Quisque non egestas justo, ac pellentesque dolor. In et diam sagittis, semper lorem id, blandit velit. Integer mattis metus vel nisi commodo porttitor. Aenean commodo commodo facilisis. Nam arcu erat, lacinia sed lacinia quis, pretium eget enim. <a href="">Embedded Link</a>  ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed maximus quam vestibulum imperdiet interdum. Cras rhoncus arcu ornare sapien sollicitudin pulvinar. Vivamus placerat purus sit amet sapien malesuada feugiat. Ut accumsan finibus nunc.</p>\r\n\r\n		<blockquote>Pull Quote : Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc id quam at nisi venenatis tempus eget vel orci neque id euismod.</blockquote>\r\n\r\n		<h3>Heading style 3</h3>\r\n\r\n		<p>Mauris vel tristique mi. Aenean libero tortor, condimentum eget efficitur sed, pulvinar dictum elit. Duis viverra lacus nec leo lacinia fringilla. Ut et est nulla. Vestibulum iaculis quam sapien, finibus luctus arcu convallis vitae. </p>\r\n		\r\n		<ol>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n			<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	       Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		</ol>\r\n\r\n		<h4>Heading Style 4</h4>\r\n\r\n		<p>In ullamcorper tempor velit in mattis. Nullam cursus sollicitudin sem, a cursus magna porta ac. In a justo tristique, auctor leo nec, gravida orci. Quisque massa nisi, imperdiet a imperdiet non, rutrum in justo. Cras tempus sollicitudin ipsum, et mattis augue porttitor et.</p>\r\n		\r\n		<ul>\r\n			\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		<li>Morbi pellentesque vulputate felis, quis fringilla magna feugiat in. In elit magna, posuere in ex a, ultrices finibus sem. 	      	    Pellentesque sodales fermentum ante eget pretium. Cras quis ornare libero, quis  laoreet ante. Mauris posuere, velit 	       	    eet condimentum sodales, urna magna tincidunt tellus.</li>\r\n		\r\n		</ul>', 'Car Accident Lawyers', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2018-02-12 17:20:25', '2018-02-12 17:20:25', '', 12, 'http://murphylaw.com/2018/02/12/12-revision-v1/', 0, 'revision', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form`
#

DROP TABLE IF EXISTS `wp_rg_form`;


#
# Table structure of table `wp_rg_form`
#

CREATE TABLE `wp_rg_form` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_trash` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_form`
#
INSERT INTO `wp_rg_form` ( `id`, `title`, `date_created`, `is_active`, `is_trash`) VALUES
(1, 'Contact Form', '2018-02-05 21:53:02', 1, 0),
(2, 'Contact Form in Nav', '2018-02-07 17:33:16', 1, 0) ;

#
# End of data contents of table `wp_rg_form`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form_meta`
#

DROP TABLE IF EXISTS `wp_rg_form_meta`;


#
# Table structure of table `wp_rg_form_meta`
#

CREATE TABLE `wp_rg_form_meta` (
  `form_id` mediumint(8) unsigned NOT NULL,
  `display_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `entries_grid_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `confirmations` longtext COLLATE utf8mb4_unicode_520_ci,
  `notifications` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_form_meta`
#
INSERT INTO `wp_rg_form_meta` ( `form_id`, `display_meta`, `entries_grid_meta`, `confirmations`, `notifications`) VALUES
(1, '{"title":"Contact Form","description":"","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Submit","imageUrl":""},"fields":[{"type":"text","id":1,"label":"Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Name","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"phone","id":2,"label":"Phone","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"phoneFormat":"standard","formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Phone","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","form_id":"","productField":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"email","id":3,"label":"Email","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Email","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","emailConfirmEnabled":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"text","id":4,"label":"Type Of Case","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Type Of Case","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"textarea","id":5,"label":"Tell Us What Happened","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Tell Us What Happened","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","form_id":"","useRichTextEditor":false,"multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"pageNumber":1,"displayOnly":""}],"version":"2.2.5","id":1,"useCurrentUserAsAuthor":true,"postContentTemplateEnabled":false,"postTitleTemplateEnabled":false,"postTitleTemplate":"","postContentTemplate":"","lastPageButton":null,"pagination":null,"firstPageCssClass":null,"notifications":{"5a78d23ecda17":{"id":"5a78d23ecda17","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}},"confirmations":{"5a78d23ecdf32":{"id":"5a78d23ecdf32","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}},"subLabelPlacement":"below","cssClass":"","enableHoneypot":true,"enableAnimation":false,"save":{"enabled":false,"button":{"type":"link","text":"Save and Continue Later"}},"limitEntries":false,"limitEntriesCount":"","limitEntriesPeriod":"","limitEntriesMessage":"","scheduleForm":false,"scheduleStart":"","scheduleStartHour":"","scheduleStartMinute":"","scheduleStartAmpm":"","scheduleEnd":"","scheduleEndHour":"","scheduleEndMinute":"","scheduleEndAmpm":"","schedulePendingMessage":"","scheduleMessage":"","requireLogin":false,"requireLoginMessage":""}', NULL, '{"5a78d23ecdf32":{"id":"5a78d23ecdf32","name":"Default Confirmation","isDefault":true,"type":"page","message":"","url":"","pageId":82,"queryString":"","disableAutoformat":false,"conditionalLogic":[]}}', '{"5a78d23ecda17":{"id":"5a78d23ecda17","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}}'),
(2, '{"title":"Contact Form in Nav","description":"","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Submit","imageUrl":""},"fields":[{"type":"text","id":1,"label":"Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Name","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"phone","id":2,"label":"Phone","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"phoneFormat":"standard","formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Phone","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","form_id":"","productField":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"email","id":3,"label":"Email","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Email","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","emailConfirmEnabled":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"text","id":4,"label":"Type Of Case","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Type Of Case","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"textarea","id":5,"label":"Tell Us What Happened","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Tell Us What Happened","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","form_id":"","useRichTextEditor":false,"multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"pageNumber":1,"displayOnly":""}],"version":"2.2.5","id":2,"useCurrentUserAsAuthor":true,"postContentTemplateEnabled":false,"postTitleTemplateEnabled":false,"postTitleTemplate":"","postContentTemplate":"","lastPageButton":null,"pagination":null,"firstPageCssClass":null,"notifications":{"5a78d23ecda17":{"id":"5a78d23ecda17","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}},"confirmations":{"5a78d23ecdf32":{"id":"5a78d23ecdf32","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}},"subLabelPlacement":"below","cssClass":"","enableHoneypot":true,"enableAnimation":false,"save":{"enabled":false,"button":{"type":"link","text":"Save and Continue Later"}},"limitEntries":false,"limitEntriesCount":"","limitEntriesPeriod":"","limitEntriesMessage":"","scheduleForm":false,"scheduleStart":"","scheduleStartHour":"","scheduleStartMinute":"","scheduleStartAmpm":"","scheduleEnd":"","scheduleEndHour":"","scheduleEndMinute":"","scheduleEndAmpm":"","schedulePendingMessage":"","scheduleMessage":"","requireLogin":false,"requireLoginMessage":""}', NULL, '{"5a78d23ecdf32":{"id":"5a78d23ecdf32","name":"Default Confirmation","isDefault":true,"type":"page","message":"","url":"","pageId":82,"queryString":"","disableAutoformat":false,"conditionalLogic":[]}}', '{"5a78d23ecda17":{"id":"5a78d23ecda17","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}}') ;

#
# End of data contents of table `wp_rg_form_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form_view`
#

DROP TABLE IF EXISTS `wp_rg_form_view`;


#
# Table structure of table `wp_rg_form_view`
#

CREATE TABLE `wp_rg_form_view` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_form_view`
#
INSERT INTO `wp_rg_form_view` ( `id`, `form_id`, `date_created`, `ip`, `count`) VALUES
(1, 1, '2018-02-05 21:57:29', '', 99),
(2, 1, '2018-02-06 21:59:29', '', 394),
(3, 1, '2018-02-07 22:10:02', '', 1088),
(4, 1, '2018-02-08 22:24:01', '', 238),
(5, 1, '2018-02-09 22:53:08', '', 20),
(6, 1, '2018-02-11 00:46:19', '', 312),
(7, 1, '2018-02-12 00:47:05', '', 547),
(8, 2, '2018-02-12 06:07:04', '', 250) ;

#
# End of data contents of table `wp_rg_form_view`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_incomplete_submissions`
#

DROP TABLE IF EXISTS `wp_rg_incomplete_submissions`;


#
# Table structure of table `wp_rg_incomplete_submissions`
#

CREATE TABLE `wp_rg_incomplete_submissions` (
  `uuid` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `submission` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_incomplete_submissions`
#

#
# End of data contents of table `wp_rg_incomplete_submissions`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead`
#

DROP TABLE IF EXISTS `wp_rg_lead`;


#
# Table structure of table `wp_rg_lead`
#

CREATE TABLE `wp_rg_lead` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_agent` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `currency` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_status` varchar(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `transaction_id` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_fulfilled` tinyint(1) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `transaction_type` tinyint(1) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'active',
  `payment_method` varchar(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead`
#

#
# End of data contents of table `wp_rg_lead`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_detail`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail`;


#
# Table structure of table `wp_rg_lead_detail`
#

CREATE TABLE `wp_rg_lead_detail` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `field_number` float NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_field_number` (`lead_id`,`field_number`),
  KEY `lead_field_value` (`value`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead_detail`
#

#
# End of data contents of table `wp_rg_lead_detail`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_detail_long`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail_long`;


#
# Table structure of table `wp_rg_lead_detail_long`
#

CREATE TABLE `wp_rg_lead_detail_long` (
  `lead_detail_id` bigint(20) unsigned NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`lead_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead_detail_long`
#

#
# End of data contents of table `wp_rg_lead_detail_long`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_meta`
#

DROP TABLE IF EXISTS `wp_rg_lead_meta`;


#
# Table structure of table `wp_rg_lead_meta`
#

CREATE TABLE `wp_rg_lead_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lead_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead_meta`
#

#
# End of data contents of table `wp_rg_lead_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_notes`
#

DROP TABLE IF EXISTS `wp_rg_lead_notes`;


#
# Table structure of table `wp_rg_lead_notes`
#

CREATE TABLE `wp_rg_lead_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `user_name` varchar(250) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  `note_type` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_user_key` (`lead_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead_notes`
#

#
# End of data contents of table `wp_rg_lead_notes`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(20, 2, 0),
(21, 2, 0),
(22, 2, 0),
(23, 2, 0),
(24, 2, 0),
(26, 2, 0),
(27, 2, 0),
(28, 2, 0),
(29, 2, 0),
(30, 2, 0),
(31, 2, 0),
(32, 2, 0),
(33, 2, 0),
(48, 3, 0),
(49, 3, 0),
(50, 3, 0),
(51, 3, 0),
(52, 3, 0),
(53, 3, 0),
(54, 3, 0),
(55, 3, 0),
(56, 3, 0),
(57, 3, 0),
(59, 3, 0),
(62, 2, 0),
(65, 2, 0),
(68, 2, 0),
(73, 2, 0),
(74, 4, 0),
(76, 4, 0),
(77, 4, 0),
(78, 4, 0),
(79, 4, 0),
(79, 5, 0),
(79, 6, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'nav_menu', '', 0, 17),
(3, 3, 'nav_menu', '', 0, 11),
(4, 4, 'category', '', 0, 5),
(5, 5, 'category', '', 0, 1),
(6, 6, 'category', '', 0, 1) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Menu 1', 'menu-1', 0),
(3, 'PA Sidebar', 'pa-sidebar', 0),
(4, 'Cat 1', 'cat-1', 0),
(5, 'Cat 2', 'cat-2', 0),
(6, 'Cat 3', 'cat-3', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', '1p21.admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '34'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:2:"::";}'),
(19, 1, 'session_tokens', 'a:2:{s:64:"ecb6cf7d11bda99b5e7e68053b4d8f0d313fbbe30a80040c5c783400c901af0f";a:4:{s:10:"expiration";i:1518483201;s:2:"ip";s:3:"::1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36";s:5:"login";i:1518310401;}s:64:"ad7fa4c144f268dbe3a4efd75987628ed9171a0e6c06261443bb190c8dbcdc99";a:4:{s:10:"expiration";i:1518626514;s:2:"ip";s:3:"::1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36";s:5:"login";i:1518453714;}}'),
(20, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(21, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(22, 1, 'nav_menu_recently_edited', '2'),
(23, 1, 'wp_user-settings', 'editor=html'),
(24, 1, 'wp_user-settings-time', '1518454037') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, '1p21.admin', '$P$B2dtOMe0TmL7jYz2M8pJqS5/Tk7kpx1', '1p21-admin', 'garrett@1pointinteractive.com', '', '2018-01-29 21:34:28', '', 0, '1p21.admin') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

