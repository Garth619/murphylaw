-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 08, 2018 at 04:18 PM
-- Server version: 5.6.38
-- PHP Version: 7.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `murphylaw`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2018-01-29 21:34:28', '2018-01-29 21:34:28', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.', 0, 'post-trashed', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

CREATE TABLE `wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

CREATE TABLE `wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://murphylaw.com', 'yes'),
(2, 'home', 'http://murphylaw.com', 'yes'),
(3, 'blogname', 'Murphy Law Firm, LLC', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'garrett@1pointinteractive.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:91:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:38:\"index.php?&page_id=6&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:1:{i:0;s:29:\"gravityforms/gravityforms.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'murphylaw', 'yes'),
(41, 'stylesheet', 'murphylaw', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '6', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'widget_search', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(95, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(96, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(97, 'widget_archives', 'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(98, 'widget_meta', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(99, 'sidebars_widgets', 'a:5:{s:19:\"wp_inactive_widgets\";a:0:{}s:7:\"sidebar\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:16:\"category_sidebar\";a:0:{}s:15:\"archive_sidebar\";a:0:{}s:13:\"array_version\";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(101, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(102, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(103, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'cron', 'a:5:{i:1518168869;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1518212086;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1518213018;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1518213164;a:1:{s:17:\"gravityforms_cron\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}', 'yes'),
(111, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:2:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.4.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.4.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.9.4-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.9.4-new-bundled.zip\";s:7:\"partial\";s:69:\"https://downloads.wordpress.org/release/wordpress-4.9.4-partial-2.zip\";s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.9.4\";s:7:\"version\";s:5:\"4.9.4\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:5:\"4.9.2\";}i:1;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.4.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.4.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.9.4-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.9.4-new-bundled.zip\";s:7:\"partial\";s:69:\"https://downloads.wordpress.org/release/wordpress-4.9.4-partial-2.zip\";s:8:\"rollback\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.9.4-rollback-2.zip\";}s:7:\"current\";s:5:\"4.9.4\";s:7:\"version\";s:5:\"4.9.4\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:5:\"4.9.2\";s:9:\"new_files\";s:0:\"\";}}s:12:\"last_checked\";i:1518125691;s:15:\"version_checked\";s:5:\"4.9.2\";s:12:\"translations\";a:0:{}}', 'no'),
(116, '_site_transient_update_themes', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1518125696;s:7:\"checked\";a:1:{s:9:\"murphylaw\";s:0:\"\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}', 'no'),
(127, 'can_compress_scripts', '0', 'no'),
(133, 'theme_mods_twentyseventeen', 'a:1:{s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1517261696;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}', 'yes'),
(134, 'current_theme', '', 'yes'),
(135, 'theme_mods_murphylaw', 'a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:2:{s:9:\"main_menu\";i:2;s:7:\"pa_menu\";i:3;}s:18:\"custom_css_post_id\";i:-1;}', 'yes'),
(136, 'theme_switched', '', 'yes'),
(139, 'WPLANG', '', 'yes'),
(140, 'new_admin_email', 'garrett@1pointinteractive.com', 'yes'),
(196, 'recently_activated', 'a:0:{}', 'yes'),
(200, 'widget_gform_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(201, 'rg_form_version', '2.2.5', 'yes'),
(204, 'rg_gforms_key', '621e21584ab7936611e0d28422299c97', 'yes'),
(205, 'rg_gforms_disable_css', '1', 'yes'),
(206, 'rg_gforms_enable_html5', '0', 'yes'),
(207, 'gform_enable_noconflict', '0', 'yes'),
(208, 'rg_gforms_enable_akismet', '', 'yes'),
(209, 'rg_gforms_captcha_public_key', '', 'yes'),
(210, 'rg_gforms_captcha_private_key', '', 'yes'),
(211, 'rg_gforms_currency', 'USD', 'yes'),
(212, 'rg_gforms_message', '<!--GFM-->', 'yes'),
(213, '_site_transient_update_plugins', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1518125695;s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:2:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"4.0.2\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.4.0.2.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:7:\"default\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";}s:7:\"banners\";a:2:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";s:7:\"default\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}}s:9:\"hello.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:3:\"1.6\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:63:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=969907\";s:2:\"2x\";s:63:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=969907\";s:7:\"default\";s:63:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=969907\";}s:7:\"banners\";a:2:{s:2:\"1x\";s:65:\"https://ps.w.org/hello-dolly/assets/banner-772x250.png?rev=478342\";s:7:\"default\";s:65:\"https://ps.w.org/hello-dolly/assets/banner-772x250.png?rev=478342\";}s:11:\"banners_rtl\";a:0:{}}}}', 'no'),
(216, 'gravityformsaddon_gravityformswebapi_version', '1.0', 'yes'),
(217, 'gf_is_upgrading', '0', 'yes'),
(218, 'gf_previous_db_version', '0', 'yes'),
(219, 'gf_db_version', '2.2.5', 'yes'),
(229, 'category_children', 'a:0:{}', 'yes'),
(267, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}', 'yes'),
(304, '_site_transient_timeout_browser_1a1754b3cfd153933070a7f8ebd3ce82', '1518646233', 'no'),
(305, '_site_transient_browser_1a1754b3cfd153933070a7f8ebd3ce82', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"63.0.3239.132\";s:8:\"platform\";s:9:\"Macintosh\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(338, '_site_transient_timeout_theme_roots', '1518127491', 'no'),
(339, '_site_transient_theme_roots', 'a:1:{s:9:\"murphylaw\";s:7:\"/themes\";}', 'no'),
(342, '_transient_timeout_gform_update_info', '1518218324', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(343, '_transient_gform_update_info', 'a:9:{s:12:\"is_valid_key\";b:1;s:6:\"reason\";s:0:\"\";s:7:\"version\";s:5:\"2.2.5\";s:3:\"url\";s:166:\"http://s3.amazonaws.com/gravityforms/releases/gravityforms_2.2.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=AhJmOy4iIJTcm6j8AQ85Q%2BptJUQ%3D\";s:15:\"expiration_time\";i:1538456400;s:9:\"offerings\";a:46:{s:12:\"gravityforms\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:5:\"2.2.5\";s:14:\"version_latest\";s:8:\"2.2.5.21\";s:3:\"url\";s:166:\"http://s3.amazonaws.com/gravityforms/releases/gravityforms_2.2.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=AhJmOy4iIJTcm6j8AQ85Q%2BptJUQ%3D\";s:10:\"url_latest\";s:167:\"http://s3.amazonaws.com/gravityforms/releases/gravityforms_2.2.5.21.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=Vd40qNsZu5WuVnDzMm9GyBoZ5uo%3D\";}s:26:\"gravityformsactivecampaign\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.4\";s:14:\"version_latest\";s:5:\"1.4.4\";s:3:\"url\";s:189:\"http://s3.amazonaws.com/gravityforms/addons/activecampaign/gravityformsactivecampaign_1.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=9Ts1DdrmDaHc9IyWQPZn9IbxBig%3D\";s:10:\"url_latest\";s:191:\"http://s3.amazonaws.com/gravityforms/addons/activecampaign/gravityformsactivecampaign_1.4.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=7T3Vbg5DKuzvZ5l1MblxqhTPoEs%3D\";}s:20:\"gravityformsagilecrm\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.1\";s:14:\"version_latest\";s:5:\"1.1.2\";s:3:\"url\";s:177:\"http://s3.amazonaws.com/gravityforms/addons/agilecrm/gravityformsagilecrm_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=7BLE7PH56nuAbwdoqCJGqpj58mg%3D\";s:10:\"url_latest\";s:179:\"http://s3.amazonaws.com/gravityforms/addons/agilecrm/gravityformsagilecrm_1.1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=gqwcMlIN9AjPsM7zscojsHlnLxY%3D\";}s:24:\"gravityformsauthorizenet\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"2.4\";s:14:\"version_latest\";s:5:\"2.4.2\";s:3:\"url\";s:185:\"http://s3.amazonaws.com/gravityforms/addons/authorizenet/gravityformsauthorizenet_2.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=mIOGo6Rw6wudHwVQLCYLUmltMlg%3D\";s:10:\"url_latest\";s:187:\"http://s3.amazonaws.com/gravityforms/addons/authorizenet/gravityformsauthorizenet_2.4.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=5yB69Lk8WhQgjzuckqx97339A5s%3D\";}s:18:\"gravityformsaweber\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"2.5\";s:14:\"version_latest\";s:5:\"2.6.1\";s:3:\"url\";s:173:\"http://s3.amazonaws.com/gravityforms/addons/aweber/gravityformsaweber_2.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=60qyS8oRmwEt9Fc4wLVeKidIecs%3D\";s:10:\"url_latest\";s:175:\"http://s3.amazonaws.com/gravityforms/addons/aweber/gravityformsaweber_2.6.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=ASgJexzXY7t1765cLMTNN9ymgQ8%3D\";}s:21:\"gravityformsbatchbook\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.2\";s:14:\"version_latest\";s:5:\"1.2.1\";s:3:\"url\";s:179:\"http://s3.amazonaws.com/gravityforms/addons/batchbook/gravityformsbatchbook_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=ikuFyolOUbT9sbA4T15qydhPvDU%3D\";s:10:\"url_latest\";s:185:\"http://s3.amazonaws.com/gravityforms/addons/batchbook/gravityformsbatchbook_1.2.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=oIqY788jyHN3MOI2N%2B%2Fd2R5I79o%3D\";}s:18:\"gravityformsbreeze\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.2\";s:14:\"version_latest\";s:5:\"1.2.1\";s:3:\"url\";s:173:\"http://s3.amazonaws.com/gravityforms/addons/breeze/gravityformsbreeze_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=u68kQ2UoMhhT9XnPbwnYfF4uZUs%3D\";s:10:\"url_latest\";s:181:\"http://s3.amazonaws.com/gravityforms/addons/breeze/gravityformsbreeze_1.2.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=SSFMgrQ%2F8A8NqZ9vUc%2B1OQtl%2BQg%3D\";}s:27:\"gravityformscampaignmonitor\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"3.5\";s:14:\"version_latest\";s:5:\"3.6.2\";s:3:\"url\";s:195:\"http://s3.amazonaws.com/gravityforms/addons/campaignmonitor/gravityformscampaignmonitor_3.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=q0F%2FYtls%2FU1H55JcKLHbxEZlFXg%3D\";s:10:\"url_latest\";s:199:\"http://s3.amazonaws.com/gravityforms/addons/campaignmonitor/gravityformscampaignmonitor_3.6.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=LyBYb%2BQFJG%2B2W5xZ%2BeWnSdY1e0M%3D\";}s:20:\"gravityformscampfire\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.1\";s:14:\"version_latest\";s:5:\"1.2.1\";s:3:\"url\";s:181:\"http://s3.amazonaws.com/gravityforms/addons/campfire/gravityformscampfire_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=QxnRXfbZNgQM6Az7B%2FYEkj%2Fubyg%3D\";s:10:\"url_latest\";s:181:\"http://s3.amazonaws.com/gravityforms/addons/campfire/gravityformscampfire_1.2.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=TCcu9WCvj%2Fu2iSgky8Gw4Jnv6Fk%3D\";}s:22:\"gravityformscapsulecrm\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.2\";s:14:\"version_latest\";s:3:\"1.2\";s:3:\"url\";s:181:\"http://s3.amazonaws.com/gravityforms/addons/capsulecrm/gravityformscapsulecrm_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=1ZopfFvOFNAn3glPWEYSbZtGF0M%3D\";s:10:\"url_latest\";s:181:\"http://s3.amazonaws.com/gravityforms/addons/capsulecrm/gravityformscapsulecrm_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=1ZopfFvOFNAn3glPWEYSbZtGF0M%3D\";}s:26:\"gravityformschainedselects\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.0\";s:14:\"version_latest\";s:5:\"1.0.6\";s:3:\"url\";s:193:\"http://s3.amazonaws.com/gravityforms/addons/chainedselects/gravityformschainedselects_1.0.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=gurhviWEbm%2FrK6rNNjmU%2FNsISXc%3D\";s:10:\"url_latest\";s:191:\"http://s3.amazonaws.com/gravityforms/addons/chainedselects/gravityformschainedselects_1.0.6.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=HZkDYsdgPkHm3CW74sdRPhnyX2Q%3D\";}s:23:\"gravityformscleverreach\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.3\";s:14:\"version_latest\";s:5:\"1.3.5\";s:3:\"url\";s:187:\"http://s3.amazonaws.com/gravityforms/addons/cleverreach/gravityformscleverreach_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=F8%2BnkqIur4p9dmpslNYjtAU%2Bem0%3D\";s:10:\"url_latest\";s:189:\"http://s3.amazonaws.com/gravityforms/addons/cleverreach/gravityformscleverreach_1.3.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=WhxLma6BYHxg7x%2FHGUFD%2FaanEEw%3D\";}s:19:\"gravityformscoupons\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"2.6\";s:14:\"version_latest\";s:5:\"2.6.2\";s:3:\"url\";s:179:\"http://s3.amazonaws.com/gravityforms/addons/coupons/gravityformscoupons_2.6.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=4nPcZPl%2B3351qkQdicXdZTp7J%2B4%3D\";s:10:\"url_latest\";s:177:\"http://s3.amazonaws.com/gravityforms/addons/coupons/gravityformscoupons_2.6.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=7LZg6koZaNPLijiIhfOuALz3vyo%3D\";}s:17:\"gravityformsdebug\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:0:\"\";s:14:\"version_latest\";s:9:\"1.0.beta8\";s:3:\"url\";s:0:\"\";s:10:\"url_latest\";s:179:\"http://s3.amazonaws.com/gravityforms/addons/debug/gravityformsdebug_1.0.beta8.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=2KGHz3A4JTbTqP7cbL4l%2BnPfSvo%3D\";}s:19:\"gravityformsdropbox\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"2.0\";s:14:\"version_latest\";s:5:\"2.0.5\";s:3:\"url\";s:175:\"http://s3.amazonaws.com/gravityforms/addons/dropbox/gravityformsdropbox_2.0.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=p72bOVMNx8w8qBJCo7C8DexlOKk%3D\";s:10:\"url_latest\";s:179:\"http://s3.amazonaws.com/gravityforms/addons/dropbox/gravityformsdropbox_2.0.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=cK8jeWYQBeWMoM%2BqzZSoBLv3IeI%3D\";}s:16:\"gravityformsemma\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.2\";s:14:\"version_latest\";s:5:\"1.2.2\";s:3:\"url\";s:171:\"http://s3.amazonaws.com/gravityforms/addons/emma/gravityformsemma_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=0jUq2FI71YRnOtCrGx8T%2Fyu7UtE%3D\";s:10:\"url_latest\";s:177:\"http://s3.amazonaws.com/gravityforms/addons/emma/gravityformsemma_1.2.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=2L1%2F%2B2d5b1sueIZHCVmD3%2B1InhY%3D\";}s:22:\"gravityformsfreshbooks\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"2.5\";s:14:\"version_latest\";s:5:\"2.5.2\";s:3:\"url\";s:183:\"http://s3.amazonaws.com/gravityforms/addons/freshbooks/gravityformsfreshbooks_2.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=ANKmRcmyVMdrGcNQCD80z%2B8NQO4%3D\";s:10:\"url_latest\";s:183:\"http://s3.amazonaws.com/gravityforms/addons/freshbooks/gravityformsfreshbooks_2.5.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=h2EHr5pM0T5zQG1Aesx3fALliaE%3D\";}s:23:\"gravityformsgetresponse\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.1\";s:14:\"version_latest\";s:5:\"1.1.2\";s:3:\"url\";s:185:\"http://s3.amazonaws.com/gravityforms/addons/getresponse/gravityformsgetresponse_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=5y6L%2FYZ2BC0navNlLGjHm8yHZhI%3D\";s:10:\"url_latest\";s:187:\"http://s3.amazonaws.com/gravityforms/addons/getresponse/gravityformsgetresponse_1.1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=VGQEDUnxBMjiAxor40Sfm7ibv%2B4%3D\";}s:21:\"gravityformsgutenberg\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:10:\"1.0-beta-1\";s:14:\"version_latest\";s:10:\"1.0-beta-1\";s:3:\"url\";s:188:\"http://s3.amazonaws.com/gravityforms/addons/gutenberg/gravityformsgutenberg_1.0-beta-1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=PmcKJS33hhkTfVYJbz%2FQSLamTWc%3D\";s:10:\"url_latest\";s:188:\"http://s3.amazonaws.com/gravityforms/addons/gutenberg/gravityformsgutenberg_1.0-beta-1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=PmcKJS33hhkTfVYJbz%2FQSLamTWc%3D\";}s:21:\"gravityformshelpscout\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.4\";s:14:\"version_latest\";s:5:\"1.4.5\";s:3:\"url\";s:179:\"http://s3.amazonaws.com/gravityforms/addons/helpscout/gravityformshelpscout_1.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=NKA8HVeNjae3v5j1OItKBlPZMAg%3D\";s:10:\"url_latest\";s:183:\"http://s3.amazonaws.com/gravityforms/addons/helpscout/gravityformshelpscout_1.4.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=U47G8GsNfw9pKt5v5ulbpEiP%2FKU%3D\";}s:20:\"gravityformshighrise\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.2\";s:14:\"version_latest\";s:5:\"1.2.3\";s:3:\"url\";s:177:\"http://s3.amazonaws.com/gravityforms/addons/highrise/gravityformshighrise_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=qJY5ahSt1XyaZYT6PeCGaMa4zms%3D\";s:10:\"url_latest\";s:181:\"http://s3.amazonaws.com/gravityforms/addons/highrise/gravityformshighrise_1.2.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=qbWr4hMywgO%2F1eeRTBsQRZnBcG0%3D\";}s:19:\"gravityformshipchat\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.1\";s:14:\"version_latest\";s:5:\"1.1.2\";s:3:\"url\";s:177:\"http://s3.amazonaws.com/gravityforms/addons/hipchat/gravityformshipchat_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=5GcPMvWZPCLBkAkviZ8y5lkx%2BIU%3D\";s:10:\"url_latest\";s:177:\"http://s3.amazonaws.com/gravityforms/addons/hipchat/gravityformshipchat_1.1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=D0hlcEP6dyujXN8e9bH86wCvYWI%3D\";}s:20:\"gravityformsicontact\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.2\";s:14:\"version_latest\";s:5:\"1.2.5\";s:3:\"url\";s:179:\"http://s3.amazonaws.com/gravityforms/addons/icontact/gravityformsicontact_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=Jy2S0tQMK8IZat6a8p4%2Fv1fMKOs%3D\";s:10:\"url_latest\";s:179:\"http://s3.amazonaws.com/gravityforms/addons/icontact/gravityformsicontact_1.2.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=R1HdWzTe5VmsT4JlSmehKRXziMM%3D\";}s:19:\"gravityformslogging\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.3\";s:14:\"version_latest\";s:5:\"1.3.1\";s:3:\"url\";s:175:\"http://s3.amazonaws.com/gravityforms/addons/logging/gravityformslogging_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=LDbU8nTHQnyfDtDfqumICNrye7U%3D\";s:10:\"url_latest\";s:179:\"http://s3.amazonaws.com/gravityforms/addons/logging/gravityformslogging_1.3.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=YDJrE%2FaTsmjj6H7H4TEt7In5HiA%3D\";}s:19:\"gravityformsmadmimi\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.1\";s:14:\"version_latest\";s:5:\"1.1.3\";s:3:\"url\";s:181:\"http://s3.amazonaws.com/gravityforms/addons/madmimi/gravityformsmadmimi_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=%2F5bN%2FxlUX3%2BrdLjdNwsF69QDW7g%3D\";s:10:\"url_latest\";s:177:\"http://s3.amazonaws.com/gravityforms/addons/madmimi/gravityformsmadmimi_1.1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=9KWnwfO9zG1JFl6q7xbBwHDGUJY%3D\";}s:21:\"gravityformsmailchimp\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"4.2\";s:14:\"version_latest\";s:5:\"4.2.5\";s:3:\"url\";s:179:\"http://s3.amazonaws.com/gravityforms/addons/mailchimp/gravityformsmailchimp_4.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=OtaNFhjrgMUXgcyKnZVolf7nD4Q%3D\";s:10:\"url_latest\";s:185:\"http://s3.amazonaws.com/gravityforms/addons/mailchimp/gravityformsmailchimp_4.2.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=%2FJNuH1Zo07EA3EfrRrfLG%2BUKzpw%3D\";}s:26:\"gravityformspartialentries\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.1\";s:14:\"version_latest\";s:3:\"1.1\";s:3:\"url\";s:193:\"http://s3.amazonaws.com/gravityforms/addons/partialentries/gravityformspartialentries_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=3Q%2FiPhABm8qqKP1X13iCQa5%2FdUE%3D\";s:10:\"url_latest\";s:193:\"http://s3.amazonaws.com/gravityforms/addons/partialentries/gravityformspartialentries_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=3Q%2FiPhABm8qqKP1X13iCQa5%2FdUE%3D\";}s:18:\"gravityformspaypal\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"2.9\";s:14:\"version_latest\";s:5:\"2.9.1\";s:3:\"url\";s:175:\"http://s3.amazonaws.com/gravityforms/addons/paypal/gravityformspaypal_2.9.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=3thfMGMpQSVz33CLnN8s%2BzIgGng%3D\";s:10:\"url_latest\";s:179:\"http://s3.amazonaws.com/gravityforms/addons/paypal/gravityformspaypal_2.9.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=Ad3%2FLk2ZZPvlmqnvhUPmvZN%2Bw88%3D\";}s:33:\"gravityformspaypalexpresscheckout\";a:3:{s:12:\"is_available\";b:0;s:7:\"version\";s:0:\"\";s:14:\"version_latest\";N;}s:29:\"gravityformspaypalpaymentspro\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"2.3\";s:14:\"version_latest\";s:3:\"2.3\";s:3:\"url\";s:199:\"http://s3.amazonaws.com/gravityforms/addons/paypalpaymentspro/gravityformspaypalpaymentspro_2.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=6os8heUvb0sM%2FepEqBS%2F6xQf87s%3D\";s:10:\"url_latest\";s:199:\"http://s3.amazonaws.com/gravityforms/addons/paypalpaymentspro/gravityformspaypalpaymentspro_2.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=6os8heUvb0sM%2FepEqBS%2F6xQf87s%3D\";}s:21:\"gravityformspaypalpro\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:5:\"1.7.2\";s:14:\"version_latest\";s:3:\"1.8\";s:3:\"url\";s:181:\"http://s3.amazonaws.com/gravityforms/addons/paypalpro/gravityformspaypalpro_1.7.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=wfdIUybM7boeqfTAlDAqjvDIrPE%3D\";s:10:\"url_latest\";s:181:\"http://s3.amazonaws.com/gravityforms/addons/paypalpro/gravityformspaypalpro_1.8.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=JWcic25Nt91%2Bk4an8UHT5aUb9vs%3D\";}s:20:\"gravityformspicatcha\";a:3:{s:12:\"is_available\";b:0;s:7:\"version\";s:3:\"2.0\";s:14:\"version_latest\";s:3:\"2.0\";}s:16:\"gravityformspipe\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.0\";s:14:\"version_latest\";s:5:\"1.0.1\";s:3:\"url\";s:169:\"http://s3.amazonaws.com/gravityforms/addons/pipe/gravityformspipe_1.0.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=H9qI4JQCC8vmuZAfG5xhYiTaBkY%3D\";s:10:\"url_latest\";s:173:\"http://s3.amazonaws.com/gravityforms/addons/pipe/gravityformspipe_1.0.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=znOShhblRpIHEo7JH%2BrrRZFSBU8%3D\";}s:17:\"gravityformspolls\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"3.1\";s:14:\"version_latest\";s:5:\"3.1.4\";s:3:\"url\";s:171:\"http://s3.amazonaws.com/gravityforms/addons/polls/gravityformspolls_3.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=SFQdAK0kZrwmCNIli7usRs1nOoY%3D\";s:10:\"url_latest\";s:173:\"http://s3.amazonaws.com/gravityforms/addons/polls/gravityformspolls_3.1.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=iHUL2vvkA7dVUuzFob1FhYeMEuU%3D\";}s:16:\"gravityformsquiz\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"3.1\";s:14:\"version_latest\";s:5:\"3.1.7\";s:3:\"url\";s:177:\"http://s3.amazonaws.com/gravityforms/addons/quiz/gravityformsquiz_3.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=WzJ6A%2BXnNjKaak%2BsP%2F%2BEItb1TVo%3D\";s:10:\"url_latest\";s:173:\"http://s3.amazonaws.com/gravityforms/addons/quiz/gravityformsquiz_3.1.7.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=NLrnapmfjhvGR%2BfhK3egwdMWptM%3D\";}s:19:\"gravityformsrestapi\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:10:\"2.0-beta-2\";s:14:\"version_latest\";s:10:\"2.0-beta-2\";s:3:\"url\";s:184:\"http://s3.amazonaws.com/gravityforms/addons/restapi/gravityformsrestapi_2.0-beta-2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=ic4JouP5Vtqr%2FABxYQ7GVBTEfvU%3D\";s:10:\"url_latest\";s:184:\"http://s3.amazonaws.com/gravityforms/addons/restapi/gravityformsrestapi_2.0-beta-2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=ic4JouP5Vtqr%2FABxYQ7GVBTEfvU%3D\";}s:21:\"gravityformssignature\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"3.4\";s:14:\"version_latest\";s:3:\"3.4\";s:3:\"url\";s:181:\"http://s3.amazonaws.com/gravityforms/addons/signature/gravityformssignature_3.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=3iR3PkD2V%2FcNhnL9qTXh8e23cvw%3D\";s:10:\"url_latest\";s:181:\"http://s3.amazonaws.com/gravityforms/addons/signature/gravityformssignature_3.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=3iR3PkD2V%2FcNhnL9qTXh8e23cvw%3D\";}s:17:\"gravityformsslack\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.7\";s:14:\"version_latest\";s:5:\"1.7.2\";s:3:\"url\";s:173:\"http://s3.amazonaws.com/gravityforms/addons/slack/gravityformsslack_1.7.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=L%2BC5HqP9GmzsW0RCwuZTQgJbtjY%3D\";s:10:\"url_latest\";s:173:\"http://s3.amazonaws.com/gravityforms/addons/slack/gravityformsslack_1.7.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=i7bLEWZIcE36n83NgM28ZQAHPmA%3D\";}s:18:\"gravityformsstripe\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"2.4\";s:14:\"version_latest\";s:3:\"2.4\";s:3:\"url\";s:173:\"http://s3.amazonaws.com/gravityforms/addons/stripe/gravityformsstripe_2.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=YZ2nT2O5JRvCdTw28XnLE2Ecy5Y%3D\";s:10:\"url_latest\";s:173:\"http://s3.amazonaws.com/gravityforms/addons/stripe/gravityformsstripe_2.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=YZ2nT2O5JRvCdTw28XnLE2Ecy5Y%3D\";}s:18:\"gravityformssurvey\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"3.2\";s:14:\"version_latest\";s:5:\"3.2.2\";s:3:\"url\";s:175:\"http://s3.amazonaws.com/gravityforms/addons/survey/gravityformssurvey_3.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=i2iqSzx%2Bb31JmLEwhoNCPSXb4P8%3D\";s:10:\"url_latest\";s:177:\"http://s3.amazonaws.com/gravityforms/addons/survey/gravityformssurvey_3.2.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=H9tivAMbwRA%2Bbe6g6BQIjU1rFoM%3D\";}s:18:\"gravityformstrello\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.2\";s:14:\"version_latest\";s:5:\"1.2.1\";s:3:\"url\";s:175:\"http://s3.amazonaws.com/gravityforms/addons/trello/gravityformstrello_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=dBTaAV%2FjJnR6X2hIuHubmec8qps%3D\";s:10:\"url_latest\";s:179:\"http://s3.amazonaws.com/gravityforms/addons/trello/gravityformstrello_1.2.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=88l7lgg%2FtEldgpQ7%2FNuU3kGHmog%3D\";}s:18:\"gravityformstwilio\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:5:\"2.4.1\";s:14:\"version_latest\";s:5:\"2.4.4\";s:3:\"url\";s:175:\"http://s3.amazonaws.com/gravityforms/addons/twilio/gravityformstwilio_2.4.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=W8neDKAB4j3RfYg2yfb06OuA1rs%3D\";s:10:\"url_latest\";s:177:\"http://s3.amazonaws.com/gravityforms/addons/twilio/gravityformstwilio_2.4.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=%2FgCMIWXogHHfZTfvfhQKLibBhbE%3D\";}s:28:\"gravityformsuserregistration\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"3.9\";s:14:\"version_latest\";s:5:\"3.9.1\";s:3:\"url\";s:195:\"http://s3.amazonaws.com/gravityforms/addons/userregistration/gravityformsuserregistration_3.9.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=mW9Rnjuam%2F0Vwhg7hQkZ5Fc5gXk%3D\";s:10:\"url_latest\";s:197:\"http://s3.amazonaws.com/gravityforms/addons/userregistration/gravityformsuserregistration_3.9.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=ADyLiZUzYGR2jNuIZkSy5nr%2B26g%3D\";}s:20:\"gravityformswebhooks\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.1\";s:14:\"version_latest\";s:5:\"1.1.4\";s:3:\"url\";s:179:\"http://s3.amazonaws.com/gravityforms/addons/webhooks/gravityformswebhooks_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=aMLyiZSa8SG%2Fm9iKMeTcto2mYiA%3D\";s:10:\"url_latest\";s:183:\"http://s3.amazonaws.com/gravityforms/addons/webhooks/gravityformswebhooks_1.1.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=UzBqwffs%2Fu9q%2BRWnkpYI3CUn1r4%3D\";}s:18:\"gravityformszapier\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"2.1\";s:14:\"version_latest\";s:5:\"2.1.5\";s:3:\"url\";s:177:\"http://s3.amazonaws.com/gravityforms/addons/zapier/gravityformszapier_2.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=TrVzsQDTLR%2FRtC%2BzbVnHc0ShPks%3D\";s:10:\"url_latest\";s:175:\"http://s3.amazonaws.com/gravityforms/addons/zapier/gravityformszapier_2.1.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=tcZEYWOMrrT9P3LzbLLCl6Yb16Y%3D\";}s:19:\"gravityformszohocrm\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.4\";s:14:\"version_latest\";s:6:\"1.4.10\";s:3:\"url\";s:175:\"http://s3.amazonaws.com/gravityforms/addons/zohocrm/gravityformszohocrm_1.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=LyURixyTdZPeIU6jSVI9DiZwKm8%3D\";s:10:\"url_latest\";s:178:\"http://s3.amazonaws.com/gravityforms/addons/zohocrm/gravityformszohocrm_1.4.10.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=8aZZkcMkkVnDde53U8aELgqQIAo%3D\";}}s:9:\"is_active\";s:1:\"1\";s:14:\"version_latest\";s:8:\"2.2.5.21\";s:10:\"url_latest\";s:167:\"http://s3.amazonaws.com/gravityforms/releases/gravityforms_2.2.5.21.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1518304724&Signature=Vd40qNsZu5WuVnDzMm9GyBoZ5uo%3D\";}', 'no'),
(348, '_transient_timeout_GFCache_d271442febb3af538baaafe9fb2236cf', '1518132238', 'no'),
(349, '_transient_GFCache_d271442febb3af538baaafe9fb2236cf', 'a:0:{}', 'no'),
(350, '_transient_timeout_GFCache_a929d2e8c3a10a42392143454985cc04', '1518132233', 'no'),
(351, '_transient_GFCache_a929d2e8c3a10a42392143454985cc04', 'a:1:{i:0;O:8:\"stdClass\":2:{s:7:\"form_id\";s:1:\"1\";s:10:\"view_count\";s:4:\"1613\";}}', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 2, '_wp_trash_meta_status', 'publish'),
(3, 2, '_wp_trash_meta_time', '1517262610'),
(4, 2, '_wp_desired_post_slug', 'sample-page'),
(5, 1, '_wp_trash_meta_status', 'publish'),
(6, 1, '_wp_trash_meta_time', '1517262613'),
(7, 1, '_wp_desired_post_slug', 'hello-world'),
(8, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:\"1\";}'),
(9, 6, '_edit_last', '1'),
(10, 6, '_edit_lock', '1517262487:1'),
(11, 6, '_wp_page_template', 'page-home.php'),
(12, 8, '_edit_last', '1'),
(13, 8, '_edit_lock', '1517954012:1'),
(14, 8, '_wp_page_template', 'default'),
(15, 10, '_edit_last', '1'),
(16, 10, '_wp_page_template', 'default'),
(17, 10, '_edit_lock', '1517954023:1'),
(18, 12, '_edit_last', '1'),
(19, 12, '_wp_page_template', 'default'),
(20, 12, '_edit_lock', '1518040461:1'),
(21, 14, '_edit_last', '1'),
(22, 14, '_wp_page_template', 'page-caseresults.php'),
(23, 14, '_edit_lock', '1518116950:1'),
(24, 16, '_edit_last', '1'),
(25, 16, '_wp_page_template', 'page-testimonials.php'),
(26, 16, '_edit_lock', '1518116798:1'),
(27, 18, '_edit_last', '1'),
(28, 18, '_edit_lock', '1517954074:1'),
(29, 18, '_wp_page_template', 'default'),
(30, 20, '_menu_item_type', 'post_type'),
(31, 20, '_menu_item_menu_item_parent', '0'),
(32, 20, '_menu_item_object_id', '6'),
(33, 20, '_menu_item_object', 'page'),
(34, 20, '_menu_item_target', ''),
(35, 20, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(36, 20, '_menu_item_xfn', ''),
(37, 20, '_menu_item_url', ''),
(39, 21, '_menu_item_type', 'post_type'),
(40, 21, '_menu_item_menu_item_parent', '0'),
(41, 21, '_menu_item_object_id', '8'),
(42, 21, '_menu_item_object', 'page'),
(43, 21, '_menu_item_target', ''),
(44, 21, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(45, 21, '_menu_item_xfn', ''),
(46, 21, '_menu_item_url', ''),
(48, 22, '_menu_item_type', 'post_type'),
(49, 22, '_menu_item_menu_item_parent', '28'),
(50, 22, '_menu_item_object_id', '10'),
(51, 22, '_menu_item_object', 'page'),
(52, 22, '_menu_item_target', ''),
(53, 22, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(54, 22, '_menu_item_xfn', ''),
(55, 22, '_menu_item_url', ''),
(57, 23, '_menu_item_type', 'post_type'),
(58, 23, '_menu_item_menu_item_parent', '0'),
(59, 23, '_menu_item_object_id', '14'),
(60, 23, '_menu_item_object', 'page'),
(61, 23, '_menu_item_target', ''),
(62, 23, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(63, 23, '_menu_item_xfn', ''),
(64, 23, '_menu_item_url', ''),
(66, 24, '_menu_item_type', 'post_type'),
(67, 24, '_menu_item_menu_item_parent', '0'),
(68, 24, '_menu_item_object_id', '18'),
(69, 24, '_menu_item_object', 'page'),
(70, 24, '_menu_item_target', ''),
(71, 24, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(72, 24, '_menu_item_xfn', ''),
(73, 24, '_menu_item_url', ''),
(75, 25, '_menu_item_type', 'post_type'),
(76, 25, '_menu_item_menu_item_parent', '0'),
(77, 25, '_menu_item_object_id', '6'),
(78, 25, '_menu_item_object', 'page'),
(79, 25, '_menu_item_target', ''),
(80, 25, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(81, 25, '_menu_item_xfn', ''),
(82, 25, '_menu_item_url', ''),
(83, 25, '_menu_item_orphaned', '1517954219'),
(84, 26, '_menu_item_type', 'post_type'),
(85, 26, '_menu_item_menu_item_parent', '31'),
(86, 26, '_menu_item_object_id', '12'),
(87, 26, '_menu_item_object', 'page'),
(88, 26, '_menu_item_target', ''),
(89, 26, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(90, 26, '_menu_item_xfn', ''),
(91, 26, '_menu_item_url', ''),
(93, 27, '_menu_item_type', 'post_type'),
(94, 27, '_menu_item_menu_item_parent', '0'),
(95, 27, '_menu_item_object_id', '16'),
(96, 27, '_menu_item_object', 'page'),
(97, 27, '_menu_item_target', ''),
(98, 27, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(99, 27, '_menu_item_xfn', ''),
(100, 27, '_menu_item_url', ''),
(102, 28, '_menu_item_type', 'custom'),
(103, 28, '_menu_item_menu_item_parent', '0'),
(104, 28, '_menu_item_object_id', '28'),
(105, 28, '_menu_item_object', 'custom'),
(106, 28, '_menu_item_target', ''),
(107, 28, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(108, 28, '_menu_item_xfn', ''),
(109, 28, '_menu_item_url', ''),
(111, 29, '_menu_item_type', 'post_type'),
(112, 29, '_menu_item_menu_item_parent', '28'),
(113, 29, '_menu_item_object_id', '10'),
(114, 29, '_menu_item_object', 'page'),
(115, 29, '_menu_item_target', ''),
(116, 29, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(117, 29, '_menu_item_xfn', ''),
(118, 29, '_menu_item_url', ''),
(120, 30, '_menu_item_type', 'post_type'),
(121, 30, '_menu_item_menu_item_parent', '28'),
(122, 30, '_menu_item_object_id', '10'),
(123, 30, '_menu_item_object', 'page'),
(124, 30, '_menu_item_target', ''),
(125, 30, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(126, 30, '_menu_item_xfn', ''),
(127, 30, '_menu_item_url', ''),
(129, 31, '_menu_item_type', 'custom'),
(130, 31, '_menu_item_menu_item_parent', '0'),
(131, 31, '_menu_item_object_id', '31'),
(132, 31, '_menu_item_object', 'custom'),
(133, 31, '_menu_item_target', ''),
(134, 31, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(135, 31, '_menu_item_xfn', ''),
(136, 31, '_menu_item_url', ''),
(138, 32, '_menu_item_type', 'post_type'),
(139, 32, '_menu_item_menu_item_parent', '31'),
(140, 32, '_menu_item_object_id', '12'),
(141, 32, '_menu_item_object', 'page'),
(142, 32, '_menu_item_target', ''),
(143, 32, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(144, 32, '_menu_item_xfn', ''),
(145, 32, '_menu_item_url', ''),
(147, 33, '_menu_item_type', 'post_type'),
(148, 33, '_menu_item_menu_item_parent', '31'),
(149, 33, '_menu_item_object_id', '12'),
(150, 33, '_menu_item_object', 'page'),
(151, 33, '_menu_item_target', ''),
(152, 33, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(153, 33, '_menu_item_xfn', ''),
(154, 33, '_menu_item_url', ''),
(155, 35, '_edit_last', '1'),
(156, 35, '_edit_lock', '1518041373:1'),
(157, 35, '_wp_page_template', 'default'),
(158, 37, '_edit_last', '1'),
(159, 37, '_wp_page_template', 'default'),
(160, 37, '_edit_lock', '1518041380:1'),
(161, 39, '_edit_last', '1'),
(162, 39, '_wp_page_template', 'default'),
(163, 39, '_edit_lock', '1518041387:1'),
(164, 41, '_edit_last', '1'),
(165, 41, '_wp_page_template', 'default'),
(166, 41, '_edit_lock', '1518041394:1'),
(167, 43, '_edit_last', '1'),
(168, 43, '_wp_page_template', 'default'),
(169, 43, '_edit_lock', '1518041400:1'),
(170, 45, '_edit_last', '1'),
(171, 45, '_wp_page_template', 'default'),
(172, 45, '_edit_lock', '1518041407:1'),
(173, 47, '_menu_item_type', 'custom'),
(174, 47, '_menu_item_menu_item_parent', '0'),
(175, 47, '_menu_item_object_id', '47'),
(176, 47, '_menu_item_object', 'custom'),
(177, 47, '_menu_item_target', ''),
(178, 47, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(179, 47, '_menu_item_xfn', ''),
(180, 47, '_menu_item_url', '#'),
(181, 47, '_menu_item_orphaned', '1518041576'),
(182, 48, '_menu_item_type', 'post_type'),
(183, 48, '_menu_item_menu_item_parent', '57'),
(184, 48, '_menu_item_object_id', '45'),
(185, 48, '_menu_item_object', 'page'),
(186, 48, '_menu_item_target', ''),
(187, 48, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(188, 48, '_menu_item_xfn', ''),
(189, 48, '_menu_item_url', ''),
(191, 49, '_menu_item_type', 'post_type'),
(192, 49, '_menu_item_menu_item_parent', '57'),
(193, 49, '_menu_item_object_id', '43'),
(194, 49, '_menu_item_object', 'page'),
(195, 49, '_menu_item_target', ''),
(196, 49, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(197, 49, '_menu_item_xfn', ''),
(198, 49, '_menu_item_url', ''),
(200, 50, '_menu_item_type', 'post_type'),
(201, 50, '_menu_item_menu_item_parent', '56'),
(202, 50, '_menu_item_object_id', '41'),
(203, 50, '_menu_item_object', 'page'),
(204, 50, '_menu_item_target', ''),
(205, 50, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(206, 50, '_menu_item_xfn', ''),
(207, 50, '_menu_item_url', ''),
(209, 51, '_menu_item_type', 'post_type'),
(210, 51, '_menu_item_menu_item_parent', '56'),
(211, 51, '_menu_item_object_id', '39'),
(212, 51, '_menu_item_object', 'page'),
(213, 51, '_menu_item_target', ''),
(214, 51, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(215, 51, '_menu_item_xfn', ''),
(216, 51, '_menu_item_url', ''),
(218, 52, '_menu_item_type', 'post_type'),
(219, 52, '_menu_item_menu_item_parent', '55'),
(220, 52, '_menu_item_object_id', '37'),
(221, 52, '_menu_item_object', 'page'),
(222, 52, '_menu_item_target', ''),
(223, 52, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(224, 52, '_menu_item_xfn', ''),
(225, 52, '_menu_item_url', ''),
(227, 53, '_menu_item_type', 'post_type'),
(228, 53, '_menu_item_menu_item_parent', '55'),
(229, 53, '_menu_item_object_id', '35'),
(230, 53, '_menu_item_object', 'page'),
(231, 53, '_menu_item_target', ''),
(232, 53, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(233, 53, '_menu_item_xfn', ''),
(234, 53, '_menu_item_url', ''),
(236, 54, '_menu_item_type', 'post_type'),
(237, 54, '_menu_item_menu_item_parent', '55'),
(238, 54, '_menu_item_object_id', '12'),
(239, 54, '_menu_item_object', 'page'),
(240, 54, '_menu_item_target', ''),
(241, 54, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(242, 54, '_menu_item_xfn', ''),
(243, 54, '_menu_item_url', ''),
(245, 55, '_menu_item_type', 'custom'),
(246, 55, '_menu_item_menu_item_parent', '0'),
(247, 55, '_menu_item_object_id', '55'),
(248, 55, '_menu_item_object', 'custom'),
(249, 55, '_menu_item_target', ''),
(250, 55, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(251, 55, '_menu_item_xfn', ''),
(252, 55, '_menu_item_url', ''),
(254, 56, '_menu_item_type', 'custom'),
(255, 56, '_menu_item_menu_item_parent', '0'),
(256, 56, '_menu_item_object_id', '56'),
(257, 56, '_menu_item_object', 'custom'),
(258, 56, '_menu_item_target', ''),
(259, 56, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(260, 56, '_menu_item_xfn', ''),
(261, 56, '_menu_item_url', ''),
(263, 57, '_menu_item_type', 'custom'),
(264, 57, '_menu_item_menu_item_parent', '0'),
(265, 57, '_menu_item_object_id', '57'),
(266, 57, '_menu_item_object', 'custom'),
(267, 57, '_menu_item_target', ''),
(268, 57, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(269, 57, '_menu_item_xfn', ''),
(270, 57, '_menu_item_url', ''),
(271, 59, '_menu_item_type', 'post_type'),
(272, 59, '_menu_item_menu_item_parent', '55'),
(273, 59, '_menu_item_object_id', '12'),
(274, 59, '_menu_item_object', 'page'),
(275, 59, '_menu_item_target', ''),
(276, 59, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(277, 59, '_menu_item_xfn', ''),
(278, 59, '_menu_item_url', ''),
(280, 60, '_edit_last', '1'),
(281, 60, '_edit_lock', '1518132067:1'),
(282, 60, '_wp_page_template', 'page-practiceareas.php'),
(283, 62, '_menu_item_type', 'post_type'),
(284, 62, '_menu_item_menu_item_parent', '31'),
(285, 62, '_menu_item_object_id', '60'),
(286, 62, '_menu_item_object', 'page'),
(287, 62, '_menu_item_target', ''),
(288, 62, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(289, 62, '_menu_item_xfn', ''),
(290, 62, '_menu_item_url', '');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

CREATE TABLE `wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2018-01-29 21:34:28', '2018-01-29 21:34:28', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world__trashed', '', '', '2018-01-29 21:50:13', '2018-01-29 21:50:13', '', 0, 'http://murphylaw.com/?p=1', 0, 'post', '', 1),
(2, 1, '2018-01-29 21:34:28', '2018-01-29 21:34:28', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href=\"http://murphylaw.com/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'trash', 'closed', 'open', '', 'sample-page__trashed', '', '', '2018-01-29 21:50:10', '2018-01-29 21:50:10', '', 0, 'http://murphylaw.com/?page_id=2', 0, 'page', '', 0),
(4, 1, '2018-01-29 21:50:10', '2018-01-29 21:50:10', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href=\"http://murphylaw.com/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2018-01-29 21:50:10', '2018-01-29 21:50:10', '', 2, 'http://murphylaw.com/2018/01/29/2-revision-v1/', 0, 'revision', '', 0),
(5, 1, '2018-01-29 21:50:13', '2018-01-29 21:50:13', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2018-01-29 21:50:13', '2018-01-29 21:50:13', '', 1, 'http://murphylaw.com/2018/01/29/1-revision-v1/', 0, 'revision', '', 0),
(6, 1, '2018-01-29 21:50:25', '2018-01-29 21:50:25', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2018-01-29 21:50:25', '2018-01-29 21:50:25', '', 0, 'http://murphylaw.com/?page_id=6', 0, 'page', '', 0),
(7, 1, '2018-01-29 21:50:25', '2018-01-29 21:50:25', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2018-01-29 21:50:25', '2018-01-29 21:50:25', '', 6, 'http://murphylaw.com/2018/01/29/6-revision-v1/', 0, 'revision', '', 0),
(8, 1, '2018-02-06 21:55:47', '2018-02-06 21:55:47', '', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2018-02-06 21:55:47', '2018-02-06 21:55:47', '', 0, 'http://murphylaw.com/?page_id=8', 0, 'page', '', 0),
(9, 1, '2018-02-06 21:55:47', '2018-02-06 21:55:47', '', 'About', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2018-02-06 21:55:47', '2018-02-06 21:55:47', '', 8, 'http://murphylaw.com/2018/02/06/8-revision-v1/', 0, 'revision', '', 0),
(10, 1, '2018-02-06 21:56:04', '2018-02-06 21:56:04', '', 'Attorney Name', '', 'publish', 'closed', 'closed', '', 'attorney-name', '', '', '2018-02-06 21:56:04', '2018-02-06 21:56:04', '', 0, 'http://murphylaw.com/?page_id=10', 0, 'page', '', 0),
(11, 1, '2018-02-06 21:56:04', '2018-02-06 21:56:04', '', 'Attorney Name', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2018-02-06 21:56:04', '2018-02-06 21:56:04', '', 10, 'http://murphylaw.com/2018/02/06/10-revision-v1/', 0, 'revision', '', 0),
(12, 1, '2018-02-06 21:56:18', '2018-02-06 21:56:18', '', 'Practice Area Examples', '', 'publish', 'closed', 'closed', '', 'practice-area-examples', '', '', '2018-02-07 21:56:43', '2018-02-07 21:56:43', '', 0, 'http://murphylaw.com/?page_id=12', 0, 'page', '', 0),
(13, 1, '2018-02-06 21:56:18', '2018-02-06 21:56:18', '', 'Practice Area Examples', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2018-02-06 21:56:18', '2018-02-06 21:56:18', '', 12, 'http://murphylaw.com/2018/02/06/12-revision-v1/', 0, 'revision', '', 0),
(14, 1, '2018-02-06 21:56:28', '2018-02-06 21:56:28', '', 'Case Results', '', 'publish', 'closed', 'closed', '', 'case-results', '', '', '2018-02-08 19:09:10', '2018-02-08 19:09:10', '', 0, 'http://murphylaw.com/?page_id=14', 0, 'page', '', 0),
(15, 1, '2018-02-06 21:56:28', '2018-02-06 21:56:28', '', 'Case Results', '', 'inherit', 'closed', 'closed', '', '14-revision-v1', '', '', '2018-02-06 21:56:28', '2018-02-06 21:56:28', '', 14, 'http://murphylaw.com/2018/02/06/14-revision-v1/', 0, 'revision', '', 0),
(16, 1, '2018-02-06 21:56:38', '2018-02-06 21:56:38', '', 'Client Testimonials', '', 'publish', 'closed', 'closed', '', 'testimonials', '', '', '2018-02-08 17:50:24', '2018-02-08 17:50:24', '', 0, 'http://murphylaw.com/?page_id=16', 0, 'page', '', 0),
(17, 1, '2018-02-06 21:56:38', '2018-02-06 21:56:38', '', 'Testimonials', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2018-02-06 21:56:38', '2018-02-06 21:56:38', '', 16, 'http://murphylaw.com/2018/02/06/16-revision-v1/', 0, 'revision', '', 0),
(18, 1, '2018-02-06 21:56:45', '2018-02-06 21:56:45', '', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2018-02-06 21:56:45', '2018-02-06 21:56:45', '', 0, 'http://murphylaw.com/?page_id=18', 0, 'page', '', 0),
(19, 1, '2018-02-06 21:56:45', '2018-02-06 21:56:45', '', 'Contact', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2018-02-06 21:56:45', '2018-02-06 21:56:45', '', 18, 'http://murphylaw.com/2018/02/06/18-revision-v1/', 0, 'revision', '', 0),
(20, 1, '2018-02-06 21:59:01', '2018-02-06 21:59:01', ' ', '', '', 'publish', 'closed', 'closed', '', '20', '', '', '2018-02-08 23:23:56', '2018-02-08 23:23:56', '', 0, 'http://murphylaw.com/?p=20', 1, 'nav_menu_item', '', 0),
(21, 1, '2018-02-06 21:59:01', '2018-02-06 21:59:01', ' ', '', '', 'publish', 'closed', 'closed', '', '21', '', '', '2018-02-08 23:23:56', '2018-02-08 23:23:56', '', 0, 'http://murphylaw.com/?p=21', 2, 'nav_menu_item', '', 0),
(22, 1, '2018-02-06 21:59:01', '2018-02-06 21:59:01', ' ', '', '', 'publish', 'closed', 'closed', '', '22', '', '', '2018-02-08 23:23:57', '2018-02-08 23:23:57', '', 0, 'http://murphylaw.com/?p=22', 4, 'nav_menu_item', '', 0),
(23, 1, '2018-02-06 21:59:01', '2018-02-06 21:59:01', ' ', '', '', 'publish', 'closed', 'closed', '', '23', '', '', '2018-02-08 23:23:57', '2018-02-08 23:23:57', '', 0, 'http://murphylaw.com/?p=23', 12, 'nav_menu_item', '', 0),
(24, 1, '2018-02-06 21:59:01', '2018-02-06 21:59:01', ' ', '', '', 'publish', 'closed', 'closed', '', '24', '', '', '2018-02-08 23:23:57', '2018-02-08 23:23:57', '', 0, 'http://murphylaw.com/?p=24', 14, 'nav_menu_item', '', 0),
(25, 1, '2018-02-06 21:56:59', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-02-06 21:56:59', '0000-00-00 00:00:00', '', 0, 'http://murphylaw.com/?p=25', 1, 'nav_menu_item', '', 0),
(26, 1, '2018-02-06 21:59:01', '2018-02-06 21:59:01', ' ', '', '', 'publish', 'closed', 'closed', '', '26', '', '', '2018-02-08 23:23:57', '2018-02-08 23:23:57', '', 0, 'http://murphylaw.com/?p=26', 8, 'nav_menu_item', '', 0),
(27, 1, '2018-02-06 21:59:01', '2018-02-06 21:59:01', ' ', '', '', 'publish', 'closed', 'closed', '', '27', '', '', '2018-02-08 23:23:57', '2018-02-08 23:23:57', '', 0, 'http://murphylaw.com/?p=27', 13, 'nav_menu_item', '', 0),
(28, 1, '2018-02-06 21:59:01', '2018-02-06 21:59:01', '', 'Team', '', 'publish', 'closed', 'closed', '', 'team', '', '', '2018-02-08 23:23:57', '2018-02-08 23:23:57', '', 0, 'http://murphylaw.com/?p=28', 3, 'nav_menu_item', '', 0),
(29, 1, '2018-02-06 21:59:01', '2018-02-06 21:59:01', ' ', '', '', 'publish', 'closed', 'closed', '', '29', '', '', '2018-02-08 23:23:57', '2018-02-08 23:23:57', '', 0, 'http://murphylaw.com/?p=29', 5, 'nav_menu_item', '', 0),
(30, 1, '2018-02-06 21:59:01', '2018-02-06 21:59:01', ' ', '', '', 'publish', 'closed', 'closed', '', '30', '', '', '2018-02-08 23:23:57', '2018-02-08 23:23:57', '', 0, 'http://murphylaw.com/?p=30', 6, 'nav_menu_item', '', 0),
(31, 1, '2018-02-06 21:59:01', '2018-02-06 21:59:01', '', 'Practice Areas', '', 'publish', 'closed', 'closed', '', 'practice-areas', '', '', '2018-02-08 23:23:57', '2018-02-08 23:23:57', '', 0, 'http://murphylaw.com/?p=31', 7, 'nav_menu_item', '', 0),
(32, 1, '2018-02-06 21:59:01', '2018-02-06 21:59:01', ' ', '', '', 'publish', 'closed', 'closed', '', '32', '', '', '2018-02-08 23:23:57', '2018-02-08 23:23:57', '', 0, 'http://murphylaw.com/?p=32', 9, 'nav_menu_item', '', 0),
(33, 1, '2018-02-06 21:59:01', '2018-02-06 21:59:01', ' ', '', '', 'publish', 'closed', 'closed', '', '33', '', '', '2018-02-08 23:23:57', '2018-02-08 23:23:57', '', 0, 'http://murphylaw.com/?p=33', 10, 'nav_menu_item', '', 0),
(34, 1, '2018-02-07 22:10:33', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-02-07 22:10:33', '0000-00-00 00:00:00', '', 0, 'http://murphylaw.com/?p=34', 0, 'post', '', 0),
(35, 1, '2018-02-07 22:11:56', '2018-02-07 22:11:56', '', 'Practice Areas Two', '', 'publish', 'closed', 'closed', '', 'practice-areas-two', '', '', '2018-02-07 22:11:56', '2018-02-07 22:11:56', '', 0, 'http://murphylaw.com/?page_id=35', 0, 'page', '', 0),
(36, 1, '2018-02-07 22:11:56', '2018-02-07 22:11:56', '', 'Practice Areas Two', '', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2018-02-07 22:11:56', '2018-02-07 22:11:56', '', 35, 'http://murphylaw.com/2018/02/07/35-revision-v1/', 0, 'revision', '', 0),
(37, 1, '2018-02-07 22:12:02', '2018-02-07 22:12:02', '', 'Practice Areas Three', '', 'publish', 'closed', 'closed', '', 'practice-areas-three', '', '', '2018-02-07 22:12:02', '2018-02-07 22:12:02', '', 0, 'http://murphylaw.com/?page_id=37', 0, 'page', '', 0),
(38, 1, '2018-02-07 22:12:02', '2018-02-07 22:12:02', '', 'Practice Areas Three', '', 'inherit', 'closed', 'closed', '', '37-revision-v1', '', '', '2018-02-07 22:12:02', '2018-02-07 22:12:02', '', 37, 'http://murphylaw.com/2018/02/07/37-revision-v1/', 0, 'revision', '', 0),
(39, 1, '2018-02-07 22:12:10', '2018-02-07 22:12:10', '', 'Practice Areas Four', '', 'publish', 'closed', 'closed', '', 'practice-areas-four', '', '', '2018-02-07 22:12:10', '2018-02-07 22:12:10', '', 0, 'http://murphylaw.com/?page_id=39', 0, 'page', '', 0),
(40, 1, '2018-02-07 22:12:10', '2018-02-07 22:12:10', '', 'Practice Areas Four', '', 'inherit', 'closed', 'closed', '', '39-revision-v1', '', '', '2018-02-07 22:12:10', '2018-02-07 22:12:10', '', 39, 'http://murphylaw.com/2018/02/07/39-revision-v1/', 0, 'revision', '', 0),
(41, 1, '2018-02-07 22:12:16', '2018-02-07 22:12:16', '', 'Practice Areas Five', '', 'publish', 'closed', 'closed', '', 'practice-areas-five', '', '', '2018-02-07 22:12:16', '2018-02-07 22:12:16', '', 0, 'http://murphylaw.com/?page_id=41', 0, 'page', '', 0),
(42, 1, '2018-02-07 22:12:16', '2018-02-07 22:12:16', '', 'Practice Areas Five', '', 'inherit', 'closed', 'closed', '', '41-revision-v1', '', '', '2018-02-07 22:12:16', '2018-02-07 22:12:16', '', 41, 'http://murphylaw.com/2018/02/07/41-revision-v1/', 0, 'revision', '', 0),
(43, 1, '2018-02-07 22:12:22', '2018-02-07 22:12:22', '', 'Practice Areas Six', '', 'publish', 'closed', 'closed', '', 'practice-areas-six', '', '', '2018-02-07 22:12:22', '2018-02-07 22:12:22', '', 0, 'http://murphylaw.com/?page_id=43', 0, 'page', '', 0),
(44, 1, '2018-02-07 22:12:22', '2018-02-07 22:12:22', '', 'Practice Areas Six', '', 'inherit', 'closed', 'closed', '', '43-revision-v1', '', '', '2018-02-07 22:12:22', '2018-02-07 22:12:22', '', 43, 'http://murphylaw.com/2018/02/07/43-revision-v1/', 0, 'revision', '', 0),
(45, 1, '2018-02-07 22:12:29', '2018-02-07 22:12:29', '', 'Practice Areas Seven', '', 'publish', 'closed', 'closed', '', 'practice-areas-seven', '', '', '2018-02-07 22:12:29', '2018-02-07 22:12:29', '', 0, 'http://murphylaw.com/?page_id=45', 0, 'page', '', 0),
(46, 1, '2018-02-07 22:12:29', '2018-02-07 22:12:29', '', 'Practice Areas Seven', '', 'inherit', 'closed', 'closed', '', '45-revision-v1', '', '', '2018-02-07 22:12:29', '2018-02-07 22:12:29', '', 45, 'http://murphylaw.com/2018/02/07/45-revision-v1/', 0, 'revision', '', 0),
(47, 1, '2018-02-07 22:12:56', '0000-00-00 00:00:00', '', 'Practice Areas Title', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-02-07 22:12:56', '0000-00-00 00:00:00', '', 0, 'http://murphylaw.com/?p=47', 1, 'nav_menu_item', '', 0),
(48, 1, '2018-02-07 22:15:08', '2018-02-07 22:15:08', ' ', '', '', 'publish', 'closed', 'closed', '', '48', '', '', '2018-02-08 23:19:05', '2018-02-08 23:19:05', '', 0, 'http://murphylaw.com/?p=48', 11, 'nav_menu_item', '', 0),
(49, 1, '2018-02-07 22:15:08', '2018-02-07 22:15:08', ' ', '', '', 'publish', 'closed', 'closed', '', '49', '', '', '2018-02-08 23:19:05', '2018-02-08 23:19:05', '', 0, 'http://murphylaw.com/?p=49', 10, 'nav_menu_item', '', 0),
(50, 1, '2018-02-07 22:15:08', '2018-02-07 22:15:08', ' ', '', '', 'publish', 'closed', 'closed', '', '50', '', '', '2018-02-08 23:19:05', '2018-02-08 23:19:05', '', 0, 'http://murphylaw.com/?p=50', 8, 'nav_menu_item', '', 0),
(51, 1, '2018-02-07 22:15:08', '2018-02-07 22:15:08', ' ', '', '', 'publish', 'closed', 'closed', '', '51', '', '', '2018-02-08 23:19:05', '2018-02-08 23:19:05', '', 0, 'http://murphylaw.com/?p=51', 7, 'nav_menu_item', '', 0),
(52, 1, '2018-02-07 22:15:08', '2018-02-07 22:15:08', ' ', '', '', 'publish', 'closed', 'closed', '', '52', '', '', '2018-02-08 23:19:05', '2018-02-08 23:19:05', '', 0, 'http://murphylaw.com/?p=52', 4, 'nav_menu_item', '', 0),
(53, 1, '2018-02-07 22:15:08', '2018-02-07 22:15:08', ' ', '', '', 'publish', 'closed', 'closed', '', '53', '', '', '2018-02-08 23:19:05', '2018-02-08 23:19:05', '', 0, 'http://murphylaw.com/?p=53', 3, 'nav_menu_item', '', 0),
(54, 1, '2018-02-07 22:15:08', '2018-02-07 22:15:08', ' ', '', '', 'publish', 'closed', 'closed', '', '54', '', '', '2018-02-08 23:19:05', '2018-02-08 23:19:05', '', 0, 'http://murphylaw.com/?p=54', 2, 'nav_menu_item', '', 0),
(55, 1, '2018-02-07 22:15:08', '2018-02-07 22:15:08', '', 'Practice Area Title', '', 'publish', 'closed', 'closed', '', 'practice-area-title', '', '', '2018-02-08 23:19:05', '2018-02-08 23:19:05', '', 0, 'http://murphylaw.com/?p=55', 1, 'nav_menu_item', '', 0),
(56, 1, '2018-02-07 22:15:08', '2018-02-07 22:15:08', '', 'Practice Areas Title', '', 'publish', 'closed', 'closed', '', 'practice-areas-title', '', '', '2018-02-08 23:19:05', '2018-02-08 23:19:05', '', 0, 'http://murphylaw.com/?p=56', 6, 'nav_menu_item', '', 0),
(57, 1, '2018-02-07 22:15:08', '2018-02-07 22:15:08', '', 'Practice Areas Title', '', 'publish', 'closed', 'closed', '', 'practice-areas-title-2', '', '', '2018-02-08 23:19:05', '2018-02-08 23:19:05', '', 0, 'http://murphylaw.com/?p=57', 9, 'nav_menu_item', '', 0),
(58, 1, '2018-02-08 17:50:24', '2018-02-08 17:50:24', '', 'Client Testimonials', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2018-02-08 17:50:24', '2018-02-08 17:50:24', '', 16, 'http://murphylaw.com/2018/02/08/16-revision-v1/', 0, 'revision', '', 0),
(59, 1, '2018-02-08 23:19:05', '2018-02-08 23:19:05', '', 'View All+', '', 'publish', 'closed', 'closed', '', 'view-all', '', '', '2018-02-08 23:19:05', '2018-02-08 23:19:05', '', 0, 'http://murphylaw.com/?p=59', 5, 'nav_menu_item', '', 0),
(60, 1, '2018-02-08 23:20:49', '2018-02-08 23:20:49', '', 'Practice Areas', '', 'publish', 'closed', 'closed', '', 'practice-areas', '', '', '2018-02-08 23:23:27', '2018-02-08 23:23:27', '', 0, 'http://murphylaw.com/?page_id=60', 0, 'page', '', 0),
(61, 1, '2018-02-08 23:20:49', '2018-02-08 23:20:49', '', 'Practice Areas', '', 'inherit', 'closed', 'closed', '', '60-revision-v1', '', '', '2018-02-08 23:20:49', '2018-02-08 23:20:49', '', 60, 'http://murphylaw.com/2018/02/08/60-revision-v1/', 0, 'revision', '', 0),
(62, 1, '2018-02-08 23:23:57', '2018-02-08 23:23:57', '', 'View All+', '', 'publish', 'closed', 'closed', '', 'view-all-2', '', '', '2018-02-08 23:23:57', '2018-02-08 23:23:57', '', 0, 'http://murphylaw.com/?p=62', 11, 'nav_menu_item', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_rg_form`
--

CREATE TABLE `wp_rg_form` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `title` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_trash` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_rg_form`
--

INSERT INTO `wp_rg_form` (`id`, `title`, `date_created`, `is_active`, `is_trash`) VALUES
(1, 'Contact Form', '2018-02-05 21:53:02', 1, 0),
(2, 'Contact Form in Nav', '2018-02-07 17:33:16', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_rg_form_meta`
--

CREATE TABLE `wp_rg_form_meta` (
  `form_id` mediumint(8) UNSIGNED NOT NULL,
  `display_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `entries_grid_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `confirmations` longtext COLLATE utf8mb4_unicode_520_ci,
  `notifications` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_rg_form_meta`
--

INSERT INTO `wp_rg_form_meta` (`form_id`, `display_meta`, `entries_grid_meta`, `confirmations`, `notifications`) VALUES
(1, '{\"title\":\"Contact Form\",\"description\":\"\",\"labelPlacement\":\"top_label\",\"descriptionPlacement\":\"below\",\"button\":{\"type\":\"text\",\"text\":\"Submit\",\"imageUrl\":\"\"},\"fields\":[{\"type\":\"text\",\"id\":1,\"label\":\"Name\",\"adminLabel\":\"\",\"isRequired\":true,\"size\":\"medium\",\"errorMessage\":\"\",\"inputs\":null,\"formId\":1,\"description\":\"\",\"allowsPrepopulate\":false,\"inputMask\":false,\"inputMaskValue\":\"\",\"inputType\":\"\",\"labelPlacement\":\"\",\"descriptionPlacement\":\"\",\"subLabelPlacement\":\"\",\"placeholder\":\"Name\",\"cssClass\":\"\",\"inputName\":\"\",\"visibility\":\"visible\",\"noDuplicates\":false,\"defaultValue\":\"\",\"choices\":\"\",\"conditionalLogic\":\"\",\"productField\":\"\",\"enablePasswordInput\":\"\",\"maxLength\":\"\",\"multipleFiles\":false,\"maxFiles\":\"\",\"calculationFormula\":\"\",\"calculationRounding\":\"\",\"enableCalculation\":\"\",\"disableQuantity\":false,\"displayAllCategories\":false,\"useRichTextEditor\":false,\"pageNumber\":1,\"displayOnly\":\"\"},{\"type\":\"phone\",\"id\":2,\"label\":\"Phone\",\"adminLabel\":\"\",\"isRequired\":true,\"size\":\"medium\",\"errorMessage\":\"\",\"inputs\":null,\"phoneFormat\":\"standard\",\"formId\":1,\"description\":\"\",\"allowsPrepopulate\":false,\"inputMask\":false,\"inputMaskValue\":\"\",\"inputType\":\"\",\"labelPlacement\":\"\",\"descriptionPlacement\":\"\",\"subLabelPlacement\":\"\",\"placeholder\":\"Phone\",\"cssClass\":\"\",\"inputName\":\"\",\"visibility\":\"visible\",\"noDuplicates\":false,\"defaultValue\":\"\",\"choices\":\"\",\"conditionalLogic\":\"\",\"form_id\":\"\",\"productField\":\"\",\"multipleFiles\":false,\"maxFiles\":\"\",\"calculationFormula\":\"\",\"calculationRounding\":\"\",\"enableCalculation\":\"\",\"disableQuantity\":false,\"displayAllCategories\":false,\"useRichTextEditor\":false,\"pageNumber\":1,\"displayOnly\":\"\"},{\"type\":\"email\",\"id\":3,\"label\":\"Email\",\"adminLabel\":\"\",\"isRequired\":true,\"size\":\"medium\",\"errorMessage\":\"\",\"inputs\":null,\"formId\":1,\"description\":\"\",\"allowsPrepopulate\":false,\"inputMask\":false,\"inputMaskValue\":\"\",\"inputType\":\"\",\"labelPlacement\":\"\",\"descriptionPlacement\":\"\",\"subLabelPlacement\":\"\",\"placeholder\":\"Email\",\"cssClass\":\"\",\"inputName\":\"\",\"visibility\":\"visible\",\"noDuplicates\":false,\"defaultValue\":\"\",\"choices\":\"\",\"conditionalLogic\":\"\",\"productField\":\"\",\"emailConfirmEnabled\":\"\",\"multipleFiles\":false,\"maxFiles\":\"\",\"calculationFormula\":\"\",\"calculationRounding\":\"\",\"enableCalculation\":\"\",\"disableQuantity\":false,\"displayAllCategories\":false,\"useRichTextEditor\":false,\"pageNumber\":1,\"displayOnly\":\"\"},{\"type\":\"text\",\"id\":4,\"label\":\"Type Of Case\",\"adminLabel\":\"\",\"isRequired\":true,\"size\":\"medium\",\"errorMessage\":\"\",\"inputs\":null,\"formId\":1,\"description\":\"\",\"allowsPrepopulate\":false,\"inputMask\":false,\"inputMaskValue\":\"\",\"inputType\":\"\",\"labelPlacement\":\"\",\"descriptionPlacement\":\"\",\"subLabelPlacement\":\"\",\"placeholder\":\"Type Of Case\",\"cssClass\":\"\",\"inputName\":\"\",\"visibility\":\"visible\",\"noDuplicates\":false,\"defaultValue\":\"\",\"choices\":\"\",\"conditionalLogic\":\"\",\"productField\":\"\",\"enablePasswordInput\":\"\",\"maxLength\":\"\",\"multipleFiles\":false,\"maxFiles\":\"\",\"calculationFormula\":\"\",\"calculationRounding\":\"\",\"enableCalculation\":\"\",\"disableQuantity\":false,\"displayAllCategories\":false,\"useRichTextEditor\":false,\"pageNumber\":1,\"displayOnly\":\"\"},{\"type\":\"textarea\",\"id\":5,\"label\":\"Tell Us What Happened\",\"adminLabel\":\"\",\"isRequired\":true,\"size\":\"medium\",\"errorMessage\":\"\",\"inputs\":null,\"formId\":1,\"description\":\"\",\"allowsPrepopulate\":false,\"inputMask\":false,\"inputMaskValue\":\"\",\"inputType\":\"\",\"labelPlacement\":\"\",\"descriptionPlacement\":\"\",\"subLabelPlacement\":\"\",\"placeholder\":\"Tell Us What Happened\",\"cssClass\":\"\",\"inputName\":\"\",\"visibility\":\"visible\",\"noDuplicates\":false,\"defaultValue\":\"\",\"choices\":\"\",\"conditionalLogic\":\"\",\"productField\":\"\",\"form_id\":\"\",\"useRichTextEditor\":false,\"multipleFiles\":false,\"maxFiles\":\"\",\"calculationFormula\":\"\",\"calculationRounding\":\"\",\"enableCalculation\":\"\",\"disableQuantity\":false,\"displayAllCategories\":false,\"pageNumber\":1,\"displayOnly\":\"\"}],\"version\":\"2.2.5\",\"id\":1,\"useCurrentUserAsAuthor\":true,\"postContentTemplateEnabled\":false,\"postTitleTemplateEnabled\":false,\"postTitleTemplate\":\"\",\"postContentTemplate\":\"\",\"lastPageButton\":null,\"pagination\":null,\"firstPageCssClass\":null,\"notifications\":{\"5a78d23ecda17\":{\"id\":\"5a78d23ecda17\",\"to\":\"{admin_email}\",\"name\":\"Admin Notification\",\"event\":\"form_submission\",\"toType\":\"email\",\"subject\":\"New submission from {form_title}\",\"message\":\"{all_fields}\"}},\"confirmations\":{\"5a78d23ecdf32\":{\"id\":\"5a78d23ecdf32\",\"name\":\"Default Confirmation\",\"isDefault\":true,\"type\":\"message\",\"message\":\"Thanks for contacting us! We will get in touch with you shortly.\",\"url\":\"\",\"pageId\":\"\",\"queryString\":\"\"}},\"subLabelPlacement\":\"below\",\"cssClass\":\"\",\"enableHoneypot\":true,\"enableAnimation\":false,\"save\":{\"enabled\":false,\"button\":{\"type\":\"link\",\"text\":\"Save and Continue Later\"}},\"limitEntries\":false,\"limitEntriesCount\":\"\",\"limitEntriesPeriod\":\"\",\"limitEntriesMessage\":\"\",\"scheduleForm\":false,\"scheduleStart\":\"\",\"scheduleStartHour\":\"\",\"scheduleStartMinute\":\"\",\"scheduleStartAmpm\":\"\",\"scheduleEnd\":\"\",\"scheduleEndHour\":\"\",\"scheduleEndMinute\":\"\",\"scheduleEndAmpm\":\"\",\"schedulePendingMessage\":\"\",\"scheduleMessage\":\"\",\"requireLogin\":false,\"requireLoginMessage\":\"\"}', NULL, '{\"5a78d23ecdf32\":{\"id\":\"5a78d23ecdf32\",\"name\":\"Default Confirmation\",\"isDefault\":true,\"type\":\"message\",\"message\":\"Thanks for contacting us! We will get in touch with you shortly.\",\"url\":\"\",\"pageId\":\"\",\"queryString\":\"\"}}', '{\"5a78d23ecda17\":{\"id\":\"5a78d23ecda17\",\"to\":\"{admin_email}\",\"name\":\"Admin Notification\",\"event\":\"form_submission\",\"toType\":\"email\",\"subject\":\"New submission from {form_title}\",\"message\":\"{all_fields}\"}}'),
(2, '{\"title\":\"Contact Form in Nav\",\"description\":\"\",\"labelPlacement\":\"top_label\",\"descriptionPlacement\":\"below\",\"button\":{\"type\":\"text\",\"text\":\"Submit\",\"imageUrl\":\"\"},\"fields\":[{\"type\":\"text\",\"id\":1,\"label\":\"Name\",\"adminLabel\":\"\",\"isRequired\":true,\"size\":\"medium\",\"errorMessage\":\"\",\"inputs\":null,\"formId\":2,\"description\":\"\",\"allowsPrepopulate\":false,\"inputMask\":false,\"inputMaskValue\":\"\",\"inputType\":\"\",\"labelPlacement\":\"\",\"descriptionPlacement\":\"\",\"subLabelPlacement\":\"\",\"placeholder\":\"Name\",\"cssClass\":\"\",\"inputName\":\"\",\"visibility\":\"visible\",\"noDuplicates\":false,\"defaultValue\":\"\",\"choices\":\"\",\"conditionalLogic\":\"\",\"productField\":\"\",\"enablePasswordInput\":\"\",\"maxLength\":\"\",\"multipleFiles\":false,\"maxFiles\":\"\",\"calculationFormula\":\"\",\"calculationRounding\":\"\",\"enableCalculation\":\"\",\"disableQuantity\":false,\"displayAllCategories\":false,\"useRichTextEditor\":false,\"pageNumber\":1,\"displayOnly\":\"\"},{\"type\":\"phone\",\"id\":2,\"label\":\"Phone\",\"adminLabel\":\"\",\"isRequired\":true,\"size\":\"medium\",\"errorMessage\":\"\",\"inputs\":null,\"phoneFormat\":\"standard\",\"formId\":2,\"description\":\"\",\"allowsPrepopulate\":false,\"inputMask\":false,\"inputMaskValue\":\"\",\"inputType\":\"\",\"labelPlacement\":\"\",\"descriptionPlacement\":\"\",\"subLabelPlacement\":\"\",\"placeholder\":\"Phone\",\"cssClass\":\"\",\"inputName\":\"\",\"visibility\":\"visible\",\"noDuplicates\":false,\"defaultValue\":\"\",\"choices\":\"\",\"conditionalLogic\":\"\",\"form_id\":\"\",\"productField\":\"\",\"multipleFiles\":false,\"maxFiles\":\"\",\"calculationFormula\":\"\",\"calculationRounding\":\"\",\"enableCalculation\":\"\",\"disableQuantity\":false,\"displayAllCategories\":false,\"useRichTextEditor\":false,\"pageNumber\":1,\"displayOnly\":\"\"},{\"type\":\"email\",\"id\":3,\"label\":\"Email\",\"adminLabel\":\"\",\"isRequired\":true,\"size\":\"medium\",\"errorMessage\":\"\",\"inputs\":null,\"formId\":2,\"description\":\"\",\"allowsPrepopulate\":false,\"inputMask\":false,\"inputMaskValue\":\"\",\"inputType\":\"\",\"labelPlacement\":\"\",\"descriptionPlacement\":\"\",\"subLabelPlacement\":\"\",\"placeholder\":\"Email\",\"cssClass\":\"\",\"inputName\":\"\",\"visibility\":\"visible\",\"noDuplicates\":false,\"defaultValue\":\"\",\"choices\":\"\",\"conditionalLogic\":\"\",\"productField\":\"\",\"emailConfirmEnabled\":\"\",\"multipleFiles\":false,\"maxFiles\":\"\",\"calculationFormula\":\"\",\"calculationRounding\":\"\",\"enableCalculation\":\"\",\"disableQuantity\":false,\"displayAllCategories\":false,\"useRichTextEditor\":false,\"pageNumber\":1,\"displayOnly\":\"\"},{\"type\":\"text\",\"id\":4,\"label\":\"Type Of Case\",\"adminLabel\":\"\",\"isRequired\":true,\"size\":\"medium\",\"errorMessage\":\"\",\"inputs\":null,\"formId\":2,\"description\":\"\",\"allowsPrepopulate\":false,\"inputMask\":false,\"inputMaskValue\":\"\",\"inputType\":\"\",\"labelPlacement\":\"\",\"descriptionPlacement\":\"\",\"subLabelPlacement\":\"\",\"placeholder\":\"Type Of Case\",\"cssClass\":\"\",\"inputName\":\"\",\"visibility\":\"visible\",\"noDuplicates\":false,\"defaultValue\":\"\",\"choices\":\"\",\"conditionalLogic\":\"\",\"productField\":\"\",\"enablePasswordInput\":\"\",\"maxLength\":\"\",\"multipleFiles\":false,\"maxFiles\":\"\",\"calculationFormula\":\"\",\"calculationRounding\":\"\",\"enableCalculation\":\"\",\"disableQuantity\":false,\"displayAllCategories\":false,\"useRichTextEditor\":false,\"pageNumber\":1,\"displayOnly\":\"\"},{\"type\":\"textarea\",\"id\":5,\"label\":\"Tell Us What Happened\",\"adminLabel\":\"\",\"isRequired\":true,\"size\":\"medium\",\"errorMessage\":\"\",\"inputs\":null,\"formId\":2,\"description\":\"\",\"allowsPrepopulate\":false,\"inputMask\":false,\"inputMaskValue\":\"\",\"inputType\":\"\",\"labelPlacement\":\"\",\"descriptionPlacement\":\"\",\"subLabelPlacement\":\"\",\"placeholder\":\"Tell Us What Happened\",\"cssClass\":\"\",\"inputName\":\"\",\"visibility\":\"visible\",\"noDuplicates\":false,\"defaultValue\":\"\",\"choices\":\"\",\"conditionalLogic\":\"\",\"productField\":\"\",\"form_id\":\"\",\"useRichTextEditor\":false,\"multipleFiles\":false,\"maxFiles\":\"\",\"calculationFormula\":\"\",\"calculationRounding\":\"\",\"enableCalculation\":\"\",\"disableQuantity\":false,\"displayAllCategories\":false,\"pageNumber\":1,\"displayOnly\":\"\"}],\"version\":\"2.2.5\",\"id\":2,\"useCurrentUserAsAuthor\":true,\"postContentTemplateEnabled\":false,\"postTitleTemplateEnabled\":false,\"postTitleTemplate\":\"\",\"postContentTemplate\":\"\",\"lastPageButton\":null,\"pagination\":null,\"firstPageCssClass\":null,\"notifications\":{\"5a78d23ecda17\":{\"id\":\"5a78d23ecda17\",\"to\":\"{admin_email}\",\"name\":\"Admin Notification\",\"event\":\"form_submission\",\"toType\":\"email\",\"subject\":\"New submission from {form_title}\",\"message\":\"{all_fields}\"}},\"confirmations\":{\"5a78d23ecdf32\":{\"id\":\"5a78d23ecdf32\",\"name\":\"Default Confirmation\",\"isDefault\":true,\"type\":\"message\",\"message\":\"Thanks for contacting us! We will get in touch with you shortly.\",\"url\":\"\",\"pageId\":\"\",\"queryString\":\"\"}},\"subLabelPlacement\":\"below\",\"cssClass\":\"\",\"enableHoneypot\":true,\"enableAnimation\":false,\"save\":{\"enabled\":false,\"button\":{\"type\":\"link\",\"text\":\"Save and Continue Later\"}},\"limitEntries\":false,\"limitEntriesCount\":\"\",\"limitEntriesPeriod\":\"\",\"limitEntriesMessage\":\"\",\"scheduleForm\":false,\"scheduleStart\":\"\",\"scheduleStartHour\":\"\",\"scheduleStartMinute\":\"\",\"scheduleStartAmpm\":\"\",\"scheduleEnd\":\"\",\"scheduleEndHour\":\"\",\"scheduleEndMinute\":\"\",\"scheduleEndAmpm\":\"\",\"schedulePendingMessage\":\"\",\"scheduleMessage\":\"\",\"requireLogin\":false,\"requireLoginMessage\":\"\"}', NULL, '{\"5a78d23ecdf32\":{\"id\":\"5a78d23ecdf32\",\"name\":\"Default Confirmation\",\"isDefault\":true,\"type\":\"message\",\"message\":\"Thanks for contacting us! We will get in touch with you shortly.\",\"url\":\"\",\"pageId\":\"\",\"queryString\":\"\"}}', '{\"5a78d23ecda17\":{\"id\":\"5a78d23ecda17\",\"to\":\"{admin_email}\",\"name\":\"Admin Notification\",\"event\":\"form_submission\",\"toType\":\"email\",\"subject\":\"New submission from {form_title}\",\"message\":\"{all_fields}\"}}');

-- --------------------------------------------------------

--
-- Table structure for table `wp_rg_form_view`
--

CREATE TABLE `wp_rg_form_view` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `form_id` mediumint(8) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `count` mediumint(8) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_rg_form_view`
--

INSERT INTO `wp_rg_form_view` (`id`, `form_id`, `date_created`, `ip`, `count`) VALUES
(1, 1, '2018-02-05 21:57:29', '', 99),
(2, 1, '2018-02-06 21:59:29', '', 394),
(3, 1, '2018-02-07 22:10:02', '', 1088),
(4, 1, '2018-02-08 22:24:01', '', 72);

-- --------------------------------------------------------

--
-- Table structure for table `wp_rg_incomplete_submissions`
--

CREATE TABLE `wp_rg_incomplete_submissions` (
  `uuid` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `form_id` mediumint(8) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `submission` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_rg_lead`
--

CREATE TABLE `wp_rg_lead` (
  `id` int(10) UNSIGNED NOT NULL,
  `form_id` mediumint(8) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_agent` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `currency` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_status` varchar(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `transaction_id` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_fulfilled` tinyint(1) DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `transaction_type` tinyint(1) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'active',
  `payment_method` varchar(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_rg_lead_detail`
--

CREATE TABLE `wp_rg_lead_detail` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `lead_id` int(10) UNSIGNED NOT NULL,
  `form_id` mediumint(8) UNSIGNED NOT NULL,
  `field_number` float NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_rg_lead_detail_long`
--

CREATE TABLE `wp_rg_lead_detail_long` (
  `lead_detail_id` bigint(20) UNSIGNED NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_rg_lead_meta`
--

CREATE TABLE `wp_rg_lead_meta` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `form_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `lead_id` bigint(20) UNSIGNED NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_rg_lead_notes`
--

CREATE TABLE `wp_rg_lead_notes` (
  `id` int(10) UNSIGNED NOT NULL,
  `lead_id` int(10) UNSIGNED NOT NULL,
  `user_name` varchar(250) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  `note_type` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Menu 1', 'menu-1', 0),
(3, 'PA Sidebar', 'pa-sidebar', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(20, 2, 0),
(21, 2, 0),
(22, 2, 0),
(23, 2, 0),
(24, 2, 0),
(26, 2, 0),
(27, 2, 0),
(28, 2, 0),
(29, 2, 0),
(30, 2, 0),
(31, 2, 0),
(32, 2, 0),
(33, 2, 0),
(48, 3, 0),
(49, 3, 0),
(50, 3, 0),
(51, 3, 0),
(52, 3, 0),
(53, 3, 0),
(54, 3, 0),
(55, 3, 0),
(56, 3, 0),
(57, 3, 0),
(59, 3, 0),
(62, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'nav_menu', '', 0, 14),
(3, 3, 'nav_menu', '', 0, 11);

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', '1p21.admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '34'),
(18, 1, 'community-events-location', 'a:1:{s:2:\"ip\";s:2:\"::\";}'),
(19, 1, 'session_tokens', 'a:1:{s:64:\"fb8fb380e8246d282f9e72e79e94c4241debba4ec7de0b4b5051a42b26681813\";a:4:{s:10:\"expiration\";i:1518213376;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:121:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36\";s:5:\"login\";i:1518040576;}}'),
(20, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(21, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:\"add-post_tag\";}'),
(22, 1, 'nav_menu_recently_edited', '2');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

CREATE TABLE `wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, '1p21.admin', '$P$B2dtOMe0TmL7jYz2M8pJqS5/Tk7kpx1', '1p21-admin', 'garrett@1pointinteractive.com', '', '2018-01-29 21:34:28', '', 0, '1p21.admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Indexes for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wp_rg_form`
--
ALTER TABLE `wp_rg_form`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_rg_form_meta`
--
ALTER TABLE `wp_rg_form_meta`
  ADD PRIMARY KEY (`form_id`);

--
-- Indexes for table `wp_rg_form_view`
--
ALTER TABLE `wp_rg_form_view`
  ADD PRIMARY KEY (`id`),
  ADD KEY `form_id` (`form_id`),
  ADD KEY `date_created` (`date_created`);

--
-- Indexes for table `wp_rg_incomplete_submissions`
--
ALTER TABLE `wp_rg_incomplete_submissions`
  ADD PRIMARY KEY (`uuid`),
  ADD KEY `form_id` (`form_id`);

--
-- Indexes for table `wp_rg_lead`
--
ALTER TABLE `wp_rg_lead`
  ADD PRIMARY KEY (`id`),
  ADD KEY `form_id` (`form_id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `wp_rg_lead_detail`
--
ALTER TABLE `wp_rg_lead_detail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `form_id` (`form_id`),
  ADD KEY `lead_id` (`lead_id`),
  ADD KEY `lead_field_number` (`lead_id`,`field_number`),
  ADD KEY `lead_field_value` (`value`(191));

--
-- Indexes for table `wp_rg_lead_detail_long`
--
ALTER TABLE `wp_rg_lead_detail_long`
  ADD PRIMARY KEY (`lead_detail_id`);

--
-- Indexes for table `wp_rg_lead_meta`
--
ALTER TABLE `wp_rg_lead_meta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lead_id` (`lead_id`);

--
-- Indexes for table `wp_rg_lead_notes`
--
ALTER TABLE `wp_rg_lead_notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lead_id` (`lead_id`),
  ADD KEY `lead_user_key` (`lead_id`,`user_id`);

--
-- Indexes for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=352;

--
-- AUTO_INCREMENT for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=291;

--
-- AUTO_INCREMENT for table `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `wp_rg_form`
--
ALTER TABLE `wp_rg_form`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_rg_form_view`
--
ALTER TABLE `wp_rg_form_view`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `wp_rg_lead`
--
ALTER TABLE `wp_rg_lead`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_rg_lead_detail`
--
ALTER TABLE `wp_rg_lead_detail`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_rg_lead_meta`
--
ALTER TABLE `wp_rg_lead_meta`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_rg_lead_notes`
--
ALTER TABLE `wp_rg_lead_notes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
